<div align="center">

# 📦 StockPro

**Solution professionnelle de gestion de stock avec abonnements**

[![Next.js](https://img.shields.io/badge/Next.js-16.1-black?style=flat-square&logo=next.js)](https://nextjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?style=flat-square&logo=typescript)](https://www.typescriptlang.org/)
[![Prisma](https://img.shields.io/badge/Prisma-6-2D3748?style=flat-square&logo=prisma)](https://www.prisma.io/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-4-38B2AC?style=flat-square&logo=tailwind-css)](https://tailwindcss.com/)
[![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE)

[🚀 Démo](#) | [📋 Fonctionnalités](#-fonctionnalités) | [🛠️ Installation](#️-installation) | [🚀 Déploiement](#-déploiement)

</div>

---

## 📋 Fonctionnalités

### 🎯 Gestion de Stock
- ✅ Suivi des stocks en temps réel
- ✅ Alertes automatiques (seuil critique)
- ✅ Mouvements d'entrée/sortie
- ✅ Prévisions IA

### 💳 Système de Paiement
- ✅ **MTN Mobile Money**
- ✅ **Celtiis Money**
- ✅ **USDC (Base Network)**
- ✅ **Pi Network**

### 📊 Abonnements
| Plan | Prix | Produits | Mouvements | Alertes |
|------|------|----------|------------|---------|
| **STARTER** | 5 000 XOF/mois | 10 | 100/mois | 10 |
| **PRO** ⭐ | 15 000 XOF/mois | 50 | 500/mois | 50 |
| **ENTERPRISE** | 50 000 XOF/mois | ∞ | ∞ | ∞ |

### 🔧 Panel Admin
- ✅ Gestion des paiements
- ✅ Génération de vouchers
- ✅ Configuration des tarifs
- ✅ Support client (tickets)
- ✅ Envoi d'emails via Outlook

---

## 🛠️ Installation

### Prérequis
- Node.js 18+ ou Bun
- SQLite (inclus)

### Démarrage rapide

```bash
# Cloner le projet
git clone https://github.com/votre-username/stockpro.git
cd stockpro

# Installer les dépendances
bun install

# Configurer l'environnement
cp .env.example .env
# Éditer .env avec vos valeurs

# Initialiser la base de données
bun run db:push

# Lancer en développement
bun run dev
```

Ouvrez [http://localhost:3000](http://localhost:3000)

---

## 🚀 Déploiement

### Vercel (Recommandé)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/votre-username/stockpro)

1. **Fork/Clone** ce repository
2. **Connectez-vous** à [Vercel](https://vercel.com)
3. **Importez** le projet depuis GitHub
4. **Configurez** les variables d'environnement :
   ```
   DATABASE_URL=file:./data.db
   ADMIN_PASSWORD=votre-mot-de-passe-securise
   ADMIN_EMAIL=votre@email.com
   ```
5. **Deploy** 🎉

### Variables d'environnement

| Variable | Description | Requis |
|----------|-------------|--------|
| `DATABASE_URL` | Chemin SQLite | ✅ |
| `ADMIN_PASSWORD` | Mot de passe admin | ✅ |
| `ADMIN_EMAIL` | Email administrateur | ✅ |
| `NEXTAUTH_SECRET` | Secret NextAuth | Optionnel |

---

## 📁 Structure du projet

```
stockpro/
├── prisma/
│   └── schema.prisma      # Modèle de données
├── src/
│   ├── app/
│   │   ├── api/           # Routes API
│   │   ├── page.tsx       # Page principale
│   │   └── layout.tsx     # Layout
│   ├── components/
│   │   ├── ui/            # Composants shadcn/ui
│   │   ├── admin-panel.tsx
│   │   └── contact-form.tsx
│   └── lib/
│       └── db.ts          # Client Prisma
├── .env.example
├── vercel.json
└── package.json
```

---

## 🔐 Sécurité

- ⚠️ **Changez le mot de passe admin** en production (`admin123` par défaut)
- 🔒 Utilisez HTTPS en production
- 🛡️ Les headers de sécurité sont configurés

---

## 📱 Screenshots

### Interface Client
> Page d'accueil avec tarifs et paiement

### Panel Admin
> Gestion complète des paiements, vouchers et support

---

## 🤝 Contribution

Les contributions sont les bienvenues !

```bash
# Créer une branche
git checkout -b feature/ma-fonctionnalite

# Commit
git commit -m "Ajout de ma fonctionnalité"

# Push
git push origin feature/ma-fonctionnalite
```

---

## 📄 License

MIT License - voir [LICENSE](LICENSE)

---

## 📞 Support

- 📧 Email: support@stockpro.bj
- 📱 WhatsApp: +229 0152877272
- 🌍 Cotonou, Bénin

---

<div align="center">

**Fait avec ❤️ au Bénin**

[⬆ Retour en haut](#-stockpro)

</div>

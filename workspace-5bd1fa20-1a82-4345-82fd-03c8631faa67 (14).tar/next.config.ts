import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Optimisation pour Vercel
  reactStrictMode: true,
  
  // Allowed origins for development
  allowedDevOrigins: ['preview-chat-5bd1fa20-1a82-4345-82fd-03c8631faa67.space.z.ai'],
  
  // Images optimization
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  },
  
  // Headers de sécurité
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin',
          },
        ],
      },
    ];
  },

  // Redirects
  async redirects() {
    return [
      {
        source: '/admin',
        destination: '/#admin',
        permanent: true,
      },
    ];
  },
};

export default nextConfig;

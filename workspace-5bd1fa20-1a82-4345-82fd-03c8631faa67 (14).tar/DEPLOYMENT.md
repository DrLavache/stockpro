# 🚀 Guide de Déploiement Vercel - StockPro

## 📋 Prérequis

1. **Compte GitHub** - [github.com](https://github.com)
2. **Compte Vercel** - [vercel.com](https://vercel.com) (gratuit)
3. **Git installé** sur votre machine

---

## 🔧 Étape 1 : Préparer le projet

### Option A : Télécharger le projet

```bash
# Créer un dossier
mkdir stockpro && cd stockpro

# Copier tous les fichiers du projet dans ce dossier
```

### Option B : Initialiser Git

```bash
# Dans le dossier du projet
git init
git add .
git commit -m "Initial commit - StockPro v1.0"
```

---

## 📤 Étape 2 : Pousser sur GitHub

```bash
# Créer un repo sur GitHub, puis :
git remote add origin https://github.com/VOTRE-USERNAME/stockpro.git
git branch -M main
git push -u origin main
```

---

## 🌐 Étape 3 : Déployer sur Vercel

### Méthode 1 : Via le site Vercel (Recommandé)

1. Allez sur [vercel.com](https://vercel.com)
2. Cliquez **"Sign Up"** → Connectez-vous avec GitHub
3. Cliquez **"Add New..."** → **"Project"**
4. Sélectionnez votre repo `stockpro`
5. Configurez les variables d'environnement :

| Name | Value |
|------|-------|
| `DATABASE_URL` | `file:./data.db` |
| `ADMIN_PASSWORD` | `votre-mot-de-passe-securise` |
| `ADMIN_EMAIL` | `icholababoukari@outlook.com` |

6. Cliquez **"Deploy"**

### Méthode 2 : Via CLI

```bash
# Installer Vercel CLI
npm i -g vercel

# Se connecter
vercel login

# Déployer
vercel

# Pour la production
vercel --prod
```

---

## ✅ Étape 4 : Configuration post-déploiement

### 1. Initialiser la base de données

Visitez votre URL Vercel + `/api/init` :
```
https://votre-app.vercel.app/api/init
```

### 2. Tester l'application

- ✅ Page d'accueil fonctionne
- ✅ Tarifs s'affichent
- ✅ Paiement accessible
- ✅ Admin panel (mot de passe configuré)

### 3. Changer le mot de passe admin

Dans Vercel Dashboard → Settings → Environment Variables :
- Modifier `ADMIN_PASSWORD` avec un mot de passe sécurisé

---

## 🔄 Mise à jour

```bash
# Modifier le code
git add .
git commit -m "Mise à jour"
git push

# Vercel redéploie automatiquement !
```

---

## 📊 Monitoring

### Logs Vercel
- Dashboard → Projet → Deployments → Cliquer sur un déploiement → Logs

### Métriques
- Dashboard → Projet → Analytics

---

## 🛠️ Dépannage

### Erreur de build
```bash
# Vérifier localement
bun run build
```

### Base de données vide
```
Visiter /api/init pour initialiser
```

### Variables d'environnement
- Vérifier dans Vercel Dashboard → Settings → Environment Variables

---

## 📱 Domaine personnalisé

1. Vercel Dashboard → Projet → Settings → Domains
2. Ajouter votre domaine
3. Configurer les DNS chez votre registrar

---

## 🔒 Sécurité production

- [ ] Changer `ADMIN_PASSWORD`
- [ ] Configurer un domaine personnalisé avec HTTPS
- [ ] Activer les logs Vercel
- [ ] Configurer les alertes d'erreur

---

## 💡 Conseils

1. **Testez localement avant de déployer**
2. **Utilisez les preview deployments** pour tester les changements
3. **Configurez les notifications** pour les déploiements
4. **Sauvegardez régulièrement** votre base de données

---

**Besoin d'aide ?** Contact: support@stockpro.bj

'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  MessageSquare, Send, Loader2, Mail, Phone, User, AlertCircle,
  CreditCard, Bug, Lightbulb, HelpCircle
} from 'lucide-react';
import { toast } from 'sonner';

const TICKET_TYPES = [
  { value: 'QUESTION', label: 'Question générale', icon: HelpCircle },
  { value: 'PAYMENT_ISSUE', label: 'Problème de paiement', icon: CreditCard },
  { value: 'COMPLAINT', label: 'Réclamation', icon: AlertCircle },
  { value: 'SUGGESTION', label: 'Suggestion', icon: Lightbulb },
  { value: 'BUG', label: 'Signaler un bug', icon: Bug },
  { value: 'OTHER', label: 'Autre', icon: MessageSquare }
];

interface ContactFormProps {
  voucherCode?: string;
  paymentId?: string;
}

export function ContactForm({ voucherCode, paymentId }: ContactFormProps) {
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  
  const [formData, setFormData] = useState({
    type: 'QUESTION',
    subject: '',
    message: '',
    userName: '',
    userEmail: '',
    userPhone: '',
    voucherCode: voucherCode || ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.subject || !formData.message || !formData.userEmail) {
      toast.error('Veuillez remplir tous les champs obligatoires');
      return;
    }
    
    setLoading(true);
    
    try {
      const res = await fetch('/api/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          paymentId
        })
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast.success('Message envoyé avec succès !');
        setSubmitted(true);
        setFormData({
          type: 'QUESTION',
          subject: '',
          message: '',
          userName: '',
          userEmail: '',
          userPhone: '',
          voucherCode: ''
        });
      } else {
        toast.error(data.error || 'Erreur lors de l\'envoi');
      }
    } catch {
      toast.error('Erreur de connexion');
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <div className="mx-auto p-4 bg-green-100 rounded-full w-fit mb-4">
            <Send className="h-8 w-8 text-green-600" />
          </div>
          <h3 className="text-xl font-bold text-green-700 mb-2">Message envoyé !</h3>
          <p className="text-muted-foreground mb-4">
            Nous avons bien reçu votre message. Notre équipe vous répondra dans les plus brefs délais.
          </p>
          <Button variant="outline" onClick={() => setSubmitted(false)}>
            Envoyer un autre message
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5" />
          Nous contacter
        </CardTitle>
        <CardDescription>
          Une question ? Un problème ? Notre équipe est là pour vous aider.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Type de demande */}
          <div className="space-y-2">
            <Label>Type de demande</Label>
            <Select
              value={formData.type}
              onValueChange={(value) => setFormData({ ...formData, type: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TICKET_TYPES.map(type => {
                  const Icon = type.icon;
                  return (
                    <SelectItem key={type.value} value={type.value}>
                      <div className="flex items-center gap-2">
                        <Icon className="h-4 w-4" />
                        {type.label}
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          {/* Sujet */}
          <div className="space-y-2">
            <Label htmlFor="subject">Sujet *</Label>
            <Input
              id="subject"
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
              placeholder="Résumez votre demande en quelques mots"
              required
            />
          </div>

          {/* Message */}
          <div className="space-y-2">
            <Label htmlFor="message">Message *</Label>
            <Textarea
              id="message"
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              placeholder="Décrivez votre demande en détail..."
              rows={5}
              required
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {/* Nom */}
            <div className="space-y-2">
              <Label htmlFor="userName">
                <User className="h-3 w-3 inline mr-1" />
                Nom (optionnel)
              </Label>
              <Input
                id="userName"
                value={formData.userName}
                onChange={(e) => setFormData({ ...formData, userName: e.target.value })}
                placeholder="Votre nom"
              />
            </div>

            {/* Email */}
            <div className="space-y-2">
              <Label htmlFor="userEmail">
                <Mail className="h-3 w-3 inline mr-1" />
                Email *
              </Label>
              <Input
                id="userEmail"
                type="email"
                value={formData.userEmail}
                onChange={(e) => setFormData({ ...formData, userEmail: e.target.value })}
                placeholder="votre@email.com"
                required
              />
            </div>
          </div>

          {/* Téléphone */}
          <div className="space-y-2">
            <Label htmlFor="userPhone">
              <Phone className="h-3 w-3 inline mr-1" />
              Téléphone (optionnel)
            </Label>
            <Input
              id="userPhone"
              type="tel"
              value={formData.userPhone}
              onChange={(e) => setFormData({ ...formData, userPhone: e.target.value })}
              placeholder="+229 XX XX XX XX"
            />
          </div>

          {/* Code voucher si applicable */}
          {formData.type === 'PAYMENT_ISSUE' && (
            <div className="space-y-2">
              <Label htmlFor="voucherCode">Code de licence (si applicable)</Label>
              <Input
                id="voucherCode"
                value={formData.voucherCode}
                onChange={(e) => setFormData({ ...formData, voucherCode: e.target.value })}
                placeholder="XXXX-XXXX-XXXX-XXXX"
                className="font-mono"
              />
            </div>
          )}

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Envoi en cours...
              </>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Envoyer le message
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

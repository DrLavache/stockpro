'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { 
  Shield, Lock, CreditCard, CheckCircle, XCircle, Clock, 
  Eye, EyeOff, Edit2, Trash2, Plus, RefreshCw, Loader2,
  Phone, Copy, Ticket, Key, Users, TrendingUp,
  DollarSign, Activity, BarChart3, MessageSquare, Bell, Zap, Star,
  Calendar, Filter, Send, Sparkles,
  Globe, Wallet, Coins, Smartphone, Mail, AlertCircle,
  Settings, Database, FileText, PieChart, ExternalLink, Link2
} from 'lucide-react';
import { toast } from 'sonner';

// Types
interface PaymentMethod {
  id: string;
  type: string;
  name: string;
  accountName?: string;
  accountNumber?: string;
  network?: string;
  instructions?: string;
  isActive: boolean;
  isVisible: boolean;
  createdAt: string;
}

interface Payment {
  id: string;
  amount: number;
  currency: string;
  paymentMethod: string;
  methodType: string;
  reference?: string;
  txHash?: string;
  status: string;
  createdAt: string;
  requestedPlan?: string;
  requestedDuration?: string;  // Database field name
  duration?: string;  // Alias for convenience
  userEmail?: string;
  userPhone?: string;
  notes?: string;
  adminNotes?: string;
  confirmedAt?: string;
}

interface Ticket {
  id: string;
  type: string;
  subject: string;
  message: string;
  userName?: string;
  userEmail: string;
  userPhone?: string;
  priority: string;
  status: string;
  adminReply?: string;
  createdAt: string;
}

interface Voucher {
  id: string;
  code: string;
  plan: string;
  duration: number;
  status: string;
  createdAt: string;
  expiresAt?: string;
  usedAt?: string;
  notes?: string;
  payment?: {
    amount: number;
    currency: string;
    userEmail?: string;
  };
}

interface PricingPlan {
  id: string;
  plan: string;
  monthlyPrice: number;
  monthlyEnabled: boolean;
  quarterlyPrice: number;
  quarterlyEnabled: boolean;
  quarterlyDiscount: number;
  yearlyPrice: number;
  yearlyEnabled: boolean;
  yearlyDiscount: number;
  features: string[];
  isActive: boolean;
  isPopular: boolean;
  displayOrder: number;
  maxProducts: number;
  maxMovements: number;
  maxAlerts: number;
}

interface AdminEmail {
  id: string;
  email: string;
  isActive: boolean;
}

const PLAN_COLORS: Record<string, string> = {
  STARTER: 'from-blue-500 to-cyan-500',
  PRO: 'from-purple-500 to-pink-500',
  ENTERPRISE: 'from-amber-500 to-orange-500'
};

const STATUS_COLORS: Record<string, string> = {
  PENDING: 'bg-yellow-100 text-yellow-800 border-yellow-300',
  AWAITING_ADMIN: 'bg-orange-100 text-orange-800 border-orange-300',
  CONFIRMED: 'bg-green-100 text-green-800 border-green-300',
  FAILED: 'bg-red-100 text-red-800 border-red-300',
  EXPIRED: 'bg-gray-100 text-gray-800 border-gray-300'
};

const STATUS_LABELS: Record<string, string> = {
  PENDING: 'En attente',
  AWAITING_ADMIN: 'Attente Admin',
  CONFIRMED: 'Confirmé',
  FAILED: 'Rejeté',
  EXPIRED: 'Expiré'
};

const DURATION_LABELS: Record<string, { label: string; days: number }> = {
  MONTHLY: { label: '1 Mois', days: 30 },
  QUARTERLY: { label: '3 Mois', days: 90 },
  YEARLY: { label: '12 Mois', days: 365 }
};

export function AdminPanel() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  
  // Data
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [pricingPlans, setPricingPlans] = useState<PricingPlan[]>([]);
  const [adminEmail, setAdminEmail] = useState<AdminEmail | null>(null);
  
  // Modals
  const [showMethodModal, setShowMethodModal] = useState(false);
  const [editingMethod, setEditingMethod] = useState<PaymentMethod | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null);
  const [showTicketModal, setShowTicketModal] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [generatedVoucher, setGeneratedVoucher] = useState<{ code: string; plan: string; duration: number } | null>(null);
  const [showVoucherResult, setShowVoucherResult] = useState(false);
  const [showVoucherModal, setShowVoucherModal] = useState(false);
  const [showPricingModal, setShowPricingModal] = useState(false);
  const [editingPricing, setEditingPricing] = useState<PricingPlan | null>(null);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  
  // Filters
  const [paymentFilter, setPaymentFilter] = useState('all');
  const [ticketFilter, setTicketFilter] = useState('all');
  const [voucherFilter, setVoucherFilter] = useState('all');
  
  // Forms
  const [methodForm, setMethodForm] = useState({
    type: 'MTN',
    name: '',
    accountName: '',
    accountNumber: '',
    network: '',
    instructions: '',
    isVisible: true
  });
  
  const [paymentForm, setPaymentForm] = useState({
    plan: 'STARTER',
    duration: 'MONTHLY',
    adminNotes: ''
  });
  
  const [ticketReply, setTicketReply] = useState('');
  
  const [voucherForm, setVoucherForm] = useState({
    plan: 'STARTER',
    duration: 30,
    notes: ''
  });
  
  const [pricingForm, setPricingForm] = useState({
    plan: 'STARTER',
    monthlyPrice: 5000,
    monthlyEnabled: true,
    quarterlyPrice: 13500,
    quarterlyEnabled: true,
    quarterlyDiscount: 10,
    yearlyPrice: 48000,
    yearlyEnabled: true,
    yearlyDiscount: 20,
    features: '',
    maxProducts: 10,
    maxMovements: 100,
    maxAlerts: 10,
    isPopular: false
  });
  
  const [settingsForm, setSettingsForm] = useState({
    email: 'icholababoukari@outlook.com'
  });

  useEffect(() => {
    if (isLoggedIn) {
      fetchAllData();
    }
  }, [isLoggedIn]);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const [methodsRes, paymentsRes, ticketsRes, vouchersRes, pricingRes, emailRes] = await Promise.all([
        fetch('/api/admin/payment-methods'),
        fetch('/api/admin/payments'),
        fetch('/api/tickets'),
        fetch('/api/admin/vouchers'),
        fetch('/api/admin/pricing'),
        fetch('/api/admin/email')
      ]);
      
      const methodsData = await methodsRes.json();
      const paymentsData = await paymentsRes.json();
      const ticketsData = await ticketsRes.json();
      const vouchersData = await vouchersRes.json();
      const pricingData = await pricingRes.json();
      const emailData = await emailRes.json();
      
      if (methodsData.success) setPaymentMethods(methodsData.methods);
      if (paymentsData.success) setPayments(paymentsData.payments);
      if (ticketsData.success) setTickets(ticketsData.tickets);
      if (vouchersData.success) setVouchers(vouchersData.vouchers);
      if (pricingData.success) setPricingPlans(pricingData.pricings.map((p: PricingPlan) => ({
        ...p,
        features: typeof p.features === 'string' ? JSON.parse(p.features) : p.features
      })));
      if (emailData.success) setAdminEmail(emailData.email);
    } catch (error) {
      console.error('Erreur:', error);
      toast.error('Erreur lors du chargement');
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async () => {
    if (!password) {
      toast.error('Veuillez entrer le mot de passe');
      return;
    }
    
    setLoading(true);
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });
      
      const data = await res.json();
      
      if (data.success) {
        setIsLoggedIn(true);
        toast.success('Bienvenue, Administrateur !');
      } else {
        toast.error(data.error || 'Mot de passe incorrect');
      }
    } catch {
      toast.error('Erreur de connexion');
    } finally {
      setLoading(false);
    }
  };

  // ============ PAYMENT METHODS ============
  const openMethodModal = (method?: PaymentMethod) => {
    if (method) {
      setEditingMethod(method);
      setMethodForm({
        type: method.type,
        name: method.name,
        accountName: method.accountName || '',
        accountNumber: method.accountNumber || '',
        network: method.network || '',
        instructions: method.instructions || '',
        isVisible: method.isVisible
      });
    } else {
      setEditingMethod(null);
      setMethodForm({
        type: 'MTN',
        name: '',
        accountName: '',
        accountNumber: '',
        network: '',
        instructions: '',
        isVisible: false
      });
    }
    setShowMethodModal(true);
  };

  const saveMethod = async () => {
    if (!methodForm.name || !methodForm.accountNumber) {
      toast.error('Veuillez remplir les champs obligatoires');
      return;
    }
    
    setLoading(true);
    try {
      const res = await fetch('/api/admin/payment-methods', {
        method: editingMethod ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editingMethod ? { id: editingMethod.id, ...methodForm } : methodForm)
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast.success(editingMethod ? 'Méthode mise à jour' : 'Méthode créée');
        setShowMethodModal(false);
        fetchAllData();
      } else {
        toast.error(data.error || 'Erreur');
      }
    } catch {
      toast.error('Erreur');
    } finally {
      setLoading(false);
    }
  };

  const deleteMethod = async (id: string) => {
    if (!confirm('Supprimer cette méthode ?')) return;
    
    try {
      const res = await fetch(`/api/admin/payment-methods?id=${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        toast.success('Supprimé');
        fetchAllData();
      }
    } catch {
      toast.error('Erreur');
    }
  };

  const toggleVisibility = async (method: PaymentMethod) => {
    try {
      const res = await fetch('/api/admin/payment-methods', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: method.id, isVisible: !method.isVisible, isActive: method.isActive })
      });
      
      if (res.ok) {
        toast.success(method.isVisible ? 'Masqué aux clients' : 'Visible aux clients');
        fetchAllData();
      }
    } catch {
      toast.error('Erreur');
    }
  };

  // ============ PAYMENTS ============
  const openPaymentModal = (payment: Payment) => {
    setSelectedPayment(payment);
    setPaymentForm({
      plan: payment.requestedPlan || 'STARTER',
      duration: payment.requestedDuration || payment.duration || 'MONTHLY',
      adminNotes: ''
    });
    setGeneratedVoucher(null);
    setShowVoucherResult(false);
    setShowPaymentModal(true);
  };

  const confirmPayment = async (action: 'confirm' | 'reject') => {
    if (!selectedPayment) return;
    
    setLoading(true);
    try {
      const res = await fetch('/api/admin/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          paymentId: selectedPayment.id,
          action,
          plan: paymentForm.plan,
          duration: paymentForm.duration,
          adminNotes: paymentForm.adminNotes
        })
      });
      
      const data = await res.json();
      
      if (data.success) {
        if (action === 'confirm' && data.voucher) {
          setGeneratedVoucher(data.voucher);
          setShowVoucherResult(true);
          toast.success('Voucher généré !');
        } else {
          toast.success(data.message);
          setShowPaymentModal(false);
        }
        fetchAllData();
      } else {
        toast.error(data.error || 'Erreur');
      }
    } catch {
      toast.error('Erreur');
    } finally {
      setLoading(false);
    }
  };

  // Generate email body for voucher
  const generateVoucherEmail = (voucher: { code: string; plan: string; duration: number }, clientEmail: string) => {
    const planName = voucher.plan;
    const durationLabel = DURATION_LABELS[voucher.duration as keyof typeof DURATION_LABELS]?.label || `${voucher.duration} jours`;
    
    const subject = encodeURIComponent(`🎉 Votre licence ${planName} StockPro est prête !`);
    const body = encodeURIComponent(`Bonjour,

Nous avons bien reçu votre paiement et nous vous en remercions ! 🙏

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎫 VOTRE CODE DE LICENCE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Code: ${voucher.code}
Plan: ${planName}
Durée: ${durationLabel}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📝 COMMENT ACTIVER VOTRE LICENCE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Connectez-vous à votre compte StockPro
2. Allez dans "Paramètres" > "Abonnement"
3. Cliquez sur "Activer une licence"
4. Entrez le code ci-dessus: ${voucher.code}
5. Cliquez sur "Activer"

Votre abonnement sera activé immédiatement !

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 BESOIN D'AIDE ?
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Si vous rencontrez des difficultés, n'hésitez pas à nous contacter:
📧 Email: support@stockpro.bj
📱 WhatsApp: +229 0152877272

Merci de votre confiance ! 🚀

L'équipe StockPro
`);
    
    return `mailto:${clientEmail}?subject=${subject}&body=${body}`;
  };

  // Open email client with voucher
  const openEmailClient = (voucher: { code: string; plan: string; duration: number }, clientEmail?: string) => {
    const email = clientEmail || adminEmail?.email || 'icholababoukari@outlook.com';
    const mailtoLink = generateVoucherEmail(voucher, email);
    window.open(mailtoLink, '_blank');
    toast.success('Client email ouvert !');
  };

  // ============ TICKETS ============
  const openTicketModal = (ticket: Ticket) => {
    setSelectedTicket(ticket);
    setTicketReply(ticket.adminReply || '');
    setShowTicketModal(true);
  };

  const replyToTicket = async () => {
    if (!selectedTicket || !ticketReply.trim()) {
      toast.error('Veuillez entrer une réponse');
      return;
    }
    
    setLoading(true);
    try {
      const res = await fetch(`/api/tickets/${selectedTicket.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: 'RESOLVED',
          adminReply: ticketReply,
          repliedBy: 'admin'
        })
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast.success('Réponse envoyée');
        setShowTicketModal(false);
        fetchAllData();
      } else {
        toast.error(data.error || 'Erreur');
      }
    } catch {
      toast.error('Erreur');
    } finally {
      setLoading(false);
    }
  };

  // ============ VOUCHERS ============
  const createManualVoucher = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/vouchers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(voucherForm)
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast.success('Voucher créé !');
        setShowVoucherModal(false);
        setVoucherForm({ plan: 'STARTER', duration: 30, notes: '' });
        fetchAllData();
      } else {
        toast.error(data.error || 'Erreur');
      }
    } catch {
      toast.error('Erreur');
    } finally {
      setLoading(false);
    }
  };

  const deleteVoucher = async (id: string) => {
    if (!confirm('Supprimer ce voucher ?')) return;
    
    try {
      const res = await fetch(`/api/admin/vouchers?id=${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        toast.success('Voucher supprimé');
        fetchAllData();
      }
    } catch {
      toast.error('Erreur');
    }
  };

  // ============ PRICING ============
  const openPricingModal = (pricing?: PricingPlan) => {
    if (pricing) {
      setEditingPricing(pricing);
      setPricingForm({
        plan: pricing.plan,
        monthlyPrice: pricing.monthlyPrice,
        monthlyEnabled: pricing.monthlyEnabled,
        quarterlyPrice: pricing.quarterlyPrice,
        quarterlyEnabled: pricing.quarterlyEnabled,
        quarterlyDiscount: pricing.quarterlyDiscount,
        yearlyPrice: pricing.yearlyPrice,
        yearlyEnabled: pricing.yearlyEnabled,
        yearlyDiscount: pricing.yearlyDiscount,
        features: Array.isArray(pricing.features) ? pricing.features.join('\n') : '',
        maxProducts: pricing.maxProducts,
        maxMovements: pricing.maxMovements,
        maxAlerts: pricing.maxAlerts,
        isPopular: pricing.isPopular
      });
    } else {
      setEditingPricing(null);
      setPricingForm({
        plan: 'STARTER',
        monthlyPrice: 5000,
        monthlyEnabled: true,
        quarterlyPrice: 13500,
        quarterlyEnabled: true,
        quarterlyDiscount: 10,
        yearlyPrice: 48000,
        yearlyEnabled: true,
        yearlyDiscount: 20,
        features: '',
        maxProducts: 10,
        maxMovements: 100,
        maxAlerts: 10,
        isPopular: false
      });
    }
    setShowPricingModal(true);
  };

  const savePricing = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/pricing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          plan: pricingForm.plan,
          ...pricingForm,
          features: pricingForm.features.split('\n').filter(f => f.trim())
        })
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast.success('Tarifs mis à jour');
        setShowPricingModal(false);
        fetchAllData();
      } else {
        toast.error(data.error || 'Erreur');
      }
    } catch {
      toast.error('Erreur');
    } finally {
      setLoading(false);
    }
  };

  // ============ SETTINGS ============
  const saveSettings = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: settingsForm.email })
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast.success('Paramètres sauvegardés');
        setShowSettingsModal(false);
        fetchAllData();
      } else {
        toast.error(data.error || 'Erreur');
      }
    } catch {
      toast.error('Erreur');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copié !');
  };

  // Stats
  const pendingPayments = payments.filter(p => p.status === 'AWAITING_ADMIN' || p.status === 'PENDING').length;
  const openTickets = tickets.filter(t => t.status === 'OPEN' || t.status === 'IN_PROGRESS').length;
  const confirmedPayments = payments.filter(p => p.status === 'CONFIRMED');
  const totalRevenue = confirmedPayments.reduce((sum, p) => sum + p.amount, 0);

  // Login Screen
  if (!isLoggedIn) {
    return (
      <div className="space-y-6">
        <Card className="max-w-md mx-auto overflow-hidden">
          <div className="h-2 bg-gradient-to-r from-purple-500 to-pink-500" />
          <CardHeader className="text-center pb-2">
            <div className="mx-auto p-4 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl w-fit mb-4 shadow-lg">
              <Shield className="h-8 w-8 text-white" />
            </div>
            <CardTitle className="text-2xl">Administration</CardTitle>
            <CardDescription>
              Accédez au panneau de gestion sécurisé
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Mot de passe administrateur</Label>
              <div className="relative">
                <Input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                  className="text-center text-lg pr-10"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <Button 
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700" 
              onClick={handleLogin} 
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Connexion...
                </>
              ) : (
                <>
                  <Lock className="h-4 w-4 mr-2" />
                  Accéder au Dashboard
                </>
              )}
            </Button>
            <Alert className="bg-amber-50 border-amber-200">
              <Key className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-xs text-amber-700">
                Mot de passe par défaut : <code className="bg-amber-100 px-2 py-0.5 rounded font-mono">admin123</code>
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl text-white">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white/20 rounded-lg">
            <Shield className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Dashboard Administrateur</h2>
            <p className="text-sm text-white/80">Gestion complète de votre plateforme</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="secondary" size="sm" onClick={() => setShowSettingsModal(true)}>
            <Settings className="h-4 w-4 mr-2" />
            Paramètres
          </Button>
          <Button variant="secondary" size="sm" onClick={fetchAllData} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Actualiser
          </Button>
          <Button variant="secondary" size="sm" onClick={() => setIsLoggedIn(false)}>
            Déconnexion
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200 hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setPaymentFilter('AWAITING_ADMIN')}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-amber-600 font-medium">En attente</p>
                <p className="text-2xl font-bold text-amber-700">{pendingPayments}</p>
              </div>
              <div className="p-2 bg-amber-200 rounded-lg">
                <Clock className="h-6 w-6 text-amber-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200 hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setTicketFilter('OPEN')}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-orange-600 font-medium">Tickets ouverts</p>
                <p className="text-2xl font-bold text-orange-700">{openTickets}</p>
              </div>
              <div className="p-2 bg-orange-200 rounded-lg">
                <MessageSquare className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200 hover:shadow-lg transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-green-600 font-medium">Confirmés</p>
                <p className="text-2xl font-bold text-green-700">{confirmedPayments.length}</p>
              </div>
              <div className="p-2 bg-green-200 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200 hover:shadow-lg transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-purple-600 font-medium">Revenus</p>
                <p className="text-lg font-bold text-purple-700">
                  {totalRevenue.toLocaleString()} XOF
                </p>
              </div>
              <div className="p-2 bg-purple-200 rounded-lg">
                <DollarSign className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200 hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setVoucherFilter('ACTIVE')}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-blue-600 font-medium">Vouchers actifs</p>
                <p className="text-2xl font-bold text-blue-700">
                  {vouchers.filter(v => v.status === 'ACTIVE').length}
                </p>
              </div>
              <div className="p-2 bg-blue-200 rounded-lg">
                <Ticket className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-pink-50 to-pink-100 border-pink-200 hover:shadow-lg transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-pink-600 font-medium">Méthodes actives</p>
                <p className="text-2xl font-bold text-pink-700">
                  {paymentMethods.filter(m => m.isVisible).length}/{paymentMethods.length}
                </p>
              </div>
              <div className="p-2 bg-pink-200 rounded-lg">
                <CreditCard className="h-6 w-6 text-pink-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 h-auto gap-1">
          <TabsTrigger value="overview" className="py-2">
            <BarChart3 className="h-4 w-4 mr-2" />
            Vue d'ensemble
          </TabsTrigger>
          <TabsTrigger value="payments" className="py-2 relative">
            <CreditCard className="h-4 w-4 mr-2" />
            Paiements
            {pendingPayments > 0 && (
              <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center bg-red-500 text-white text-xs">
                {pendingPayments}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="tickets" className="py-2 relative">
            <MessageSquare className="h-4 w-4 mr-2" />
            Support
            {openTickets > 0 && (
              <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center bg-orange-500 text-white text-xs">
                {openTickets}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="vouchers" className="py-2">
            <Ticket className="h-4 w-4 mr-2" />
            Vouchers
          </TabsTrigger>
          <TabsTrigger value="pricing" className="py-2">
            <DollarSign className="h-4 w-4 mr-2" />
            Tarifs
          </TabsTrigger>
        </TabsList>

        {/* OVERVIEW */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Revenue by Plan */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <PieChart className="h-5 w-5 text-purple-500" />
                  Répartition par Plan
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {['STARTER', 'PRO', 'ENTERPRISE'].map(plan => {
                  const count = confirmedPayments.filter(p => p.requestedPlan === plan).length;
                  const total = confirmedPayments.length || 1;
                  const percent = Math.round((count / total) * 100);
                  const pricing = pricingPlans.find(p => p.plan === plan);
                  const revenue = count * (pricing?.monthlyPrice || 0);
                  
                  return (
                    <div key={plan} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${PLAN_COLORS[plan]}`} />
                          <span className="font-medium">{plan}</span>
                        </div>
                        <span className="text-muted-foreground">
                          {count} ventes ({percent}%)
                        </span>
                      </div>
                      <Progress value={percent} className="h-2" />
                      <p className="text-xs text-muted-foreground">
                        Revenus: <span className="font-medium text-slate-700">{revenue.toLocaleString()} XOF</span>
                      </p>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Payment Methods Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <CreditCard className="h-5 w-5 text-pink-500" />
                  Méthodes de Paiement
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {['MTN', 'CELTIIS', 'CRYPTO'].map(method => {
                  const count = payments.filter(p => p.methodType === method).length;
                  const total = payments.length || 1;
                  const percent = Math.round((count / total) * 100);
                  
                  return (
                    <div key={method} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <div className="flex items-center gap-2">
                          {method === 'MTN' && <Smartphone className="h-4 w-4 text-yellow-500" />}
                          {method === 'CELTIIS' && <Smartphone className="h-4 w-4 text-green-500" />}
                          {method === 'CRYPTO' && <Coins className="h-4 w-4 text-orange-500" />}
                          <span className="font-medium">{method}</span>
                        </div>
                        <span className="text-muted-foreground">
                          {count} transactions ({percent}%)
                        </span>
                      </div>
                      <Progress value={percent} className="h-2" />
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Activity className="h-5 w-5 text-blue-500" />
                Activité Récente
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="max-h-[400px]">
                {payments.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Aucune activité récente</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {payments.slice(0, 15).map(payment => (
                      <div 
                        key={payment.id} 
                        className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                        onClick={() => openPaymentModal(payment)}
                      >
                        <div className="flex items-center gap-4">
                          {payment.status === 'CONFIRMED' ? (
                            <div className="p-2 bg-green-100 rounded-lg">
                              <CheckCircle className="h-5 w-5 text-green-600" />
                            </div>
                          ) : payment.status === 'FAILED' ? (
                            <div className="p-2 bg-red-100 rounded-lg">
                              <XCircle className="h-5 w-5 text-red-600" />
                            </div>
                          ) : (
                            <div className="p-2 bg-amber-100 rounded-lg">
                              <Clock className="h-5 w-5 text-amber-600" />
                            </div>
                          )}
                          <div>
                            <p className="font-medium">
                              {payment.amount.toLocaleString()} {payment.currency} - {payment.requestedPlan || 'N/A'}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {payment.userEmail || payment.userPhone || 'Anonyme'} • {payment.paymentMethod}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge className={STATUS_COLORS[payment.status]}>
                            {STATUS_LABELS[payment.status]}
                          </Badge>
                          <p className="text-xs text-muted-foreground mt-1">
                            {new Date(payment.createdAt).toLocaleDateString('fr-FR', {
                              day: '2-digit',
                              month: 'short',
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* PAYMENTS */}
        <TabsContent value="payments">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <CardTitle>Gestion des Paiements</CardTitle>
                  <CardDescription>Confirmez les paiements pour générer les licences</CardDescription>
                </div>
                <Select value={paymentFilter} onValueChange={setPaymentFilter}>
                  <SelectTrigger className="w-[180px]">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous</SelectItem>
                    <SelectItem value="AWAITING_ADMIN">En attente</SelectItem>
                    <SelectItem value="CONFIRMED">Confirmés</SelectItem>
                    <SelectItem value="FAILED">Rejetés</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="max-h-[600px]">
                {payments.filter(p => paymentFilter === 'all' || p.status === paymentFilter).length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <CheckCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Aucun paiement à afficher</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {payments.filter(p => paymentFilter === 'all' || p.status === paymentFilter).map(payment => (
                      <div 
                        key={payment.id} 
                        className={`p-4 border rounded-lg transition-all hover:shadow-md ${
                          payment.status === 'AWAITING_ADMIN' || payment.status === 'PENDING' 
                            ? 'bg-amber-50 border-amber-300' 
                            : 'bg-card'
                        }`}
                      >
                        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
                          <div className="space-y-2 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge className={STATUS_COLORS[payment.status]}>
                                {STATUS_LABELS[payment.status]}
                              </Badge>
                              {payment.reference && (
                                <code className="text-xs bg-slate-100 px-2 py-0.5 rounded font-mono">
                                  {payment.reference}
                                </code>
                              )}
                              <Badge variant="outline" className="font-medium">
                                {payment.requestedPlan || 'N/A'}
                              </Badge>
                              {(payment.requestedDuration || payment.duration) && (
                                <Badge variant="secondary" className="text-xs">
                                  {DURATION_LABELS[payment.requestedDuration || payment.duration]?.label || payment.requestedDuration || payment.duration}
                                </Badge>
                              )}
                            </div>
                            
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                              <div>
                                <span className="text-muted-foreground">Montant: </span>
                                <span className="font-bold text-lg">{payment.amount.toLocaleString()} {payment.currency}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Méthode: </span>
                                <span className="font-medium">{payment.paymentMethod}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Date: </span>
                                <span>{new Date(payment.createdAt).toLocaleString('fr-FR')}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Email: </span>
                                <span className="text-xs">{payment.userEmail || '-'}</span>
                              </div>
                            </div>
                            
                            {payment.userPhone && (
                              <p className="text-sm"><span className="text-muted-foreground">Tél: </span>{payment.userPhone}</p>
                            )}
                            {payment.notes && (
                              <p className="text-sm text-muted-foreground italic">"{payment.notes}"</p>
                            )}
                          </div>
                          
                          {(payment.status === 'AWAITING_ADMIN' || payment.status === 'PENDING') && (
                            <Button 
                              onClick={() => openPaymentModal(payment)}
                              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shrink-0"
                            >
                              <Zap className="h-4 w-4 mr-2" />
                              Traiter
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* TICKETS */}
        <TabsContent value="tickets">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <CardTitle>Support Client</CardTitle>
                  <CardDescription>Gérez les demandes et réclamations</CardDescription>
                </div>
                <Select value={ticketFilter} onValueChange={setTicketFilter}>
                  <SelectTrigger className="w-[180px]">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous</SelectItem>
                    <SelectItem value="OPEN">Ouverts</SelectItem>
                    <SelectItem value="IN_PROGRESS">En cours</SelectItem>
                    <SelectItem value="RESOLVED">Résolus</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="max-h-[600px]">
                {tickets.filter(t => ticketFilter === 'all' || t.status === ticketFilter).length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Aucun ticket</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {tickets.filter(t => ticketFilter === 'all' || t.status === ticketFilter).map(ticket => (
                      <div key={ticket.id} className="p-4 border rounded-lg bg-card hover:shadow-md transition-all">
                        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
                          <div className="space-y-2 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge className={ticket.status === 'OPEN' ? 'bg-blue-100 text-blue-800' : ticket.status === 'RESOLVED' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                                {ticket.status}
                              </Badge>
                              <Badge className={ticket.priority === 'URGENT' ? 'bg-red-100 text-red-800' : ticket.priority === 'HIGH' ? 'bg-orange-100 text-orange-800' : 'bg-blue-100 text-blue-800'}>
                                {ticket.priority}
                              </Badge>
                            </div>
                            
                            <h4 className="font-medium">{ticket.subject}</h4>
                            <p className="text-sm text-muted-foreground line-clamp-2">{ticket.message}</p>
                            
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Users className="h-3 w-3" />
                                {ticket.userName || 'Anonyme'}
                              </span>
                              <span className="flex items-center gap-1">
                                <Mail className="h-3 w-3" />
                                {ticket.userEmail}
                              </span>
                              <span>{new Date(ticket.createdAt).toLocaleString('fr-FR')}</span>
                            </div>
                          </div>
                          
                          {ticket.status !== 'CLOSED' && ticket.status !== 'RESOLVED' && (
                            <Button variant="outline" onClick={() => openTicketModal(ticket)} className="shrink-0">
                              <Send className="h-4 w-4 mr-2" />
                              Répondre
                            </Button>
                          )}
                        </div>
                        
                        {ticket.adminReply && (
                          <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                            <p className="text-xs text-green-600 font-medium mb-1">Réponse admin:</p>
                            <p className="text-sm text-green-800">{ticket.adminReply}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* VOUCHERS */}
        <TabsContent value="vouchers">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <CardTitle>Gestion des Vouchers</CardTitle>
                  <CardDescription>Codes de licence et activations</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Select value={voucherFilter} onValueChange={setVoucherFilter}>
                    <SelectTrigger className="w-[150px]">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="ACTIVE">Actifs</SelectItem>
                      <SelectItem value="USED">Utilisés</SelectItem>
                      <SelectItem value="EXPIRED">Expirés</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button onClick={() => setShowVoucherModal(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Créer
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="max-h-[600px]">
                {vouchers.filter(v => voucherFilter === 'all' || v.status === voucherFilter).length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <Ticket className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Aucun voucher</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {vouchers.filter(v => voucherFilter === 'all' || v.status === voucherFilter).map(voucher => (
                      <div 
                        key={voucher.id} 
                        className={`p-4 border rounded-lg transition-all ${
                          voucher.status === 'ACTIVE' 
                            ? 'bg-green-50 border-green-200' 
                            : voucher.status === 'USED'
                            ? 'bg-slate-50 border-slate-200'
                            : 'bg-red-50 border-red-200'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <code className="text-lg font-mono font-bold bg-white px-3 py-1 rounded border">
                                {voucher.code}
                              </code>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 w-7 p-0"
                                onClick={() => copyToClipboard(voucher.code)}
                              >
                                <Copy className="h-3 w-3" />
                              </Button>
                              <Badge className={`bg-gradient-to-r ${PLAN_COLORS[voucher.plan]} text-white`}>
                                {voucher.plan}
                              </Badge>
                              <Badge variant="outline">
                                {voucher.duration} jours
                              </Badge>
                              <Badge className={
                                voucher.status === 'ACTIVE' ? 'bg-green-500 text-white' :
                                voucher.status === 'USED' ? 'bg-slate-500 text-white' :
                                'bg-red-500 text-white'
                              }>
                                {voucher.status}
                              </Badge>
                            </div>
                            
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span>Créé: {new Date(voucher.createdAt).toLocaleDateString('fr-FR')}</span>
                              {voucher.expiresAt && (
                                <span>Expire: {new Date(voucher.expiresAt).toLocaleDateString('fr-FR')}</span>
                              )}
                              {voucher.usedAt && (
                                <span>Utilisé: {new Date(voucher.usedAt).toLocaleDateString('fr-FR')}</span>
                              )}
                            </div>
                            
                            {voucher.payment && (
                              <p className="text-xs text-muted-foreground">
                                Paiement: {voucher.payment.amount?.toLocaleString()} XOF • {voucher.payment.userEmail || 'N/A'}
                              </p>
                            )}
                          </div>
                          
                          <div className="flex items-center gap-2">
                            {voucher.status === 'ACTIVE' && voucher.payment?.userEmail && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => openEmailClient(voucher, voucher.payment?.userEmail)}
                                title="Envoyer par email"
                              >
                                <Mail className="h-4 w-4 mr-1" />
                                Email
                              </Button>
                            )}
                            {voucher.status === 'ACTIVE' && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-destructive hover:text-destructive"
                                onClick={() => deleteVoucher(voucher.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* PRICING */}
        <TabsContent value="pricing">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Configuration des Tarifs</CardTitle>
                  <CardDescription>Gérez les prix et options d'abonnement</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" onClick={() => openMethodModal()}>
                    <CreditCard className="h-4 w-4 mr-2" />
                    Moyens de paiement
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                {pricingPlans.map(pricing => (
                  <Card 
                    key={pricing.id}
                    className={`relative overflow-hidden ${pricing.isPopular ? 'border-2 border-purple-500 shadow-lg' : 'border-slate-200'}`}
                  >
                    {pricing.isPopular && (
                      <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold py-1 text-center">
                        <Star className="h-3 w-3 inline mr-1" />
                        POPULAIRE
                      </div>
                    )}
                    
                    <CardHeader className={pricing.isPopular ? 'pt-8' : ''}>
                      <div className="flex items-center justify-between">
                        <div className={`w-10 h-10 bg-gradient-to-br ${PLAN_COLORS[pricing.plan]} rounded-xl flex items-center justify-center`}>
                          <Zap className="h-5 w-5 text-white" />
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => openPricingModal(pricing)}>
                          <Edit2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <CardTitle className="text-xl mt-2">{pricing.plan}</CardTitle>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      {/* Monthly */}
                      {pricing.monthlyEnabled && (
                        <div className="p-2 bg-slate-50 rounded-lg">
                          <div className="flex justify-between items-center">
                            <span className="text-sm">Mensuel</span>
                            <span className="font-bold">{pricing.monthlyPrice.toLocaleString()} XOF</span>
                          </div>
                        </div>
                      )}
                      
                      {/* Quarterly */}
                      {pricing.quarterlyEnabled && (
                        <div className="p-2 bg-slate-50 rounded-lg">
                          <div className="flex justify-between items-center">
                            <span className="text-sm">Trimestriel</span>
                            <div className="text-right">
                              <span className="font-bold">{pricing.quarterlyPrice.toLocaleString()} XOF</span>
                              <Badge variant="secondary" className="ml-2 text-xs">-{pricing.quarterlyDiscount}%</Badge>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {/* Yearly */}
                      {pricing.yearlyEnabled && (
                        <div className="p-2 bg-green-50 rounded-lg border border-green-200">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium text-green-700">Annuel</span>
                            <div className="text-right">
                              <span className="font-bold text-green-700">{pricing.yearlyPrice.toLocaleString()} XOF</span>
                              <Badge className="ml-2 bg-green-500 text-white text-xs">-{pricing.yearlyDiscount}%</Badge>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {/* Limits */}
                      <div className="text-xs text-muted-foreground space-y-1 pt-2 border-t">
                        <p>Produits: {pricing.maxProducts === 999999 ? 'Illimité' : pricing.maxProducts}</p>
                        <p>Mouvements: {pricing.maxMovements === 999999 ? 'Illimité' : pricing.maxMovements}/mois</p>
                        <p>Alertes: {pricing.maxAlerts === 999999 ? 'Illimité' : pricing.maxAlerts}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              {/* Payment Methods */}
              <Separator className="my-6" />
              
              <div className="space-y-4">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Moyens de Paiement
                </h3>
                
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {paymentMethods.map(method => (
                    <Card key={method.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            {method.type === 'MTN' && <Smartphone className="h-5 w-5 text-yellow-500" />}
                            {method.type === 'CELTIIS' && <Smartphone className="h-5 w-5 text-green-500" />}
                            {method.type === 'CRYPTO' && <Coins className="h-5 w-5 text-orange-500" />}
                            <span className="font-medium text-sm">{method.name}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 w-7 p-0"
                              onClick={() => toggleVisibility(method)}
                            >
                              {method.isVisible ? <Eye className="h-4 w-4 text-green-500" /> : <EyeOff className="h-4 w-4 text-slate-400" />}
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 w-7 p-0"
                              onClick={() => openMethodModal(method)}
                            >
                              <Edit2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <code className="text-xs bg-slate-100 px-2 py-1 rounded font-mono block">
                          {method.accountNumber}
                        </code>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* PAYMENT MODAL */}
      <Dialog open={showPaymentModal} onOpenChange={setShowPaymentModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-purple-500" />
              Traiter le Paiement
            </DialogTitle>
          </DialogHeader>
          
          {showVoucherResult && generatedVoucher ? (
            <div className="space-y-4 py-4">
              <div className="text-center">
                <div className="mx-auto p-4 bg-green-100 rounded-full w-fit mb-4">
                  <CheckCircle className="h-10 w-10 text-green-600" />
                </div>
                <h3 className="text-lg font-bold text-green-700 mb-2">Voucher Généré !</h3>
              </div>
              
              <div className="p-4 bg-slate-50 rounded-lg text-center">
                <p className="text-sm text-muted-foreground mb-2">Code de licence</p>
                <code className="text-2xl font-mono font-bold block mb-2">{generatedVoucher.code}</code>
                <div className="flex items-center justify-center gap-2">
                  <Badge className={`bg-gradient-to-r ${PLAN_COLORS[generatedVoucher.plan]} text-white`}>
                    {generatedVoucher.plan}
                  </Badge>
                  <Badge variant="outline">{generatedVoucher.duration} jours</Badge>
                </div>
              </div>
              
              <Alert>
                <Mail className="h-4 w-4" />
                <AlertDescription className="text-xs">
                  Cliquez sur "Envoyer par Email" pour ouvrir Outlook avec un message pré-rédigé.
                </AlertDescription>
              </Alert>
              
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => copyToClipboard(generatedVoucher.code)}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copier
                </Button>
                <Button
                  className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600"
                  onClick={() => openEmailClient(generatedVoucher, selectedPayment?.userEmail)}
                >
                  <Mail className="h-4 w-4 mr-2" />
                  Email
                </Button>
              </div>
              
              <Button variant="outline" className="w-full" onClick={() => setShowPaymentModal(false)}>
                Fermer
              </Button>
            </div>
          ) : (
            <>
              <div className="space-y-4">
                <div className="p-4 bg-slate-50 rounded-lg space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Montant</span>
                    <span className="font-bold">{selectedPayment?.amount.toLocaleString()} {selectedPayment?.currency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Méthode</span>
                    <span>{selectedPayment?.paymentMethod}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Référence</span>
                    <code className="text-sm">{selectedPayment?.reference}</code>
                  </div>
                  {selectedPayment?.userEmail && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Email</span>
                      <span className="text-sm">{selectedPayment.userEmail}</span>
                    </div>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label>Plan à activer</Label>
                  <Select
                    value={paymentForm.plan}
                    onValueChange={(value) => setPaymentForm({ ...paymentForm, plan: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {['STARTER', 'PRO', 'ENTERPRISE'].map(plan => (
                        <SelectItem key={plan} value={plan}>
                          <div className="flex items-center gap-2">
                            <Badge className={`bg-gradient-to-r ${PLAN_COLORS[plan]} text-white`}>
                              {plan}
                            </Badge>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Durée</Label>
                  <Select
                    value={paymentForm.duration}
                    onValueChange={(value) => setPaymentForm({ ...paymentForm, duration: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MONTHLY">1 Mois</SelectItem>
                      <SelectItem value="QUARTERLY">3 Mois (-10%)</SelectItem>
                      <SelectItem value="YEARLY">12 Mois (-20%)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Notes admin</Label>
                  <Textarea
                    value={paymentForm.adminNotes}
                    onChange={(e) => setPaymentForm({ ...paymentForm, adminNotes: e.target.value })}
                    placeholder="Commentaires..."
                    rows={2}
                  />
                </div>
              </div>
              
              <DialogFooter className="flex-col gap-2">
                <div className="flex gap-2 w-full">
                  <Button
                    variant="destructive"
                    className="flex-1"
                    onClick={() => confirmPayment('reject')}
                    disabled={loading}
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    Rejeter
                  </Button>
                  <Button
                    className="flex-1 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"
                    onClick={() => confirmPayment('confirm')}
                    disabled={loading}
                  >
                    {loading ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <CheckCircle className="h-4 w-4 mr-2" />
                    )}
                    Confirmer
                  </Button>
                </div>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* TICKET MODAL */}
      <Dialog open={showTicketModal} onOpenChange={setShowTicketModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Répondre au Ticket</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-lg">
              <p className="text-sm font-medium">{selectedTicket?.subject}</p>
              <p className="text-sm text-muted-foreground mt-1">{selectedTicket?.message}</p>
            </div>
            
            <div className="space-y-2">
              <Label>Votre réponse</Label>
              <Textarea
                value={ticketReply}
                onChange={(e) => setTicketReply(e.target.value)}
                placeholder="Votre réponse au client..."
                rows={4}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTicketModal(false)}>
              Annuler
            </Button>
            <Button onClick={replyToTicket} disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Send className="h-4 w-4 mr-2" />}
              Envoyer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* VOUCHER MODAL */}
      <Dialog open={showVoucherModal} onOpenChange={setShowVoucherModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Créer un Voucher Manuel</DialogTitle>
            <DialogDescription>
              Générez un code de licence sans paiement associé
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Plan</Label>
                <Select
                  value={voucherForm.plan}
                  onValueChange={(value) => setVoucherForm({ ...voucherForm, plan: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {['STARTER', 'PRO', 'ENTERPRISE'].map(plan => (
                      <SelectItem key={plan} value={plan}>{plan}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Durée (jours)</Label>
                <Input
                  type="number"
                  value={voucherForm.duration}
                  onChange={(e) => setVoucherForm({ ...voucherForm, duration: parseInt(e.target.value) || 30 })}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea
                value={voucherForm.notes}
                onChange={(e) => setVoucherForm({ ...voucherForm, notes: e.target.value })}
                placeholder="Raison de la création..."
                rows={2}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowVoucherModal(false)}>
              Annuler
            </Button>
            <Button onClick={createManualVoucher} disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Ticket className="h-4 w-4 mr-2" />}
              Générer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* PRICING MODAL */}
      <Dialog open={showPricingModal} onOpenChange={setShowPricingModal}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Modifier les Tarifs - {pricingForm.plan}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Monthly */}
            <div className="p-4 border rounded-lg space-y-3">
              <div className="flex items-center justify-between">
                <Label className="font-semibold">Mensuel</Label>
                <Switch
                  checked={pricingForm.monthlyEnabled}
                  onCheckedChange={(checked) => setPricingForm({ ...pricingForm, monthlyEnabled: checked })}
                />
              </div>
              {pricingForm.monthlyEnabled && (
                <div className="space-y-2">
                  <Label>Prix (XOF)</Label>
                  <Input
                    type="number"
                    value={pricingForm.monthlyPrice}
                    onChange={(e) => setPricingForm({ ...pricingForm, monthlyPrice: parseFloat(e.target.value) || 0 })}
                  />
                </div>
              )}
            </div>
            
            {/* Quarterly */}
            <div className="p-4 border rounded-lg space-y-3">
              <div className="flex items-center justify-between">
                <Label className="font-semibold">Trimestriel (3 mois)</Label>
                <Switch
                  checked={pricingForm.quarterlyEnabled}
                  onCheckedChange={(checked) => setPricingForm({ ...pricingForm, quarterlyEnabled: checked })}
                />
              </div>
              {pricingForm.quarterlyEnabled && (
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Prix (XOF)</Label>
                    <Input
                      type="number"
                      value={pricingForm.quarterlyPrice}
                      onChange={(e) => setPricingForm({ ...pricingForm, quarterlyPrice: parseFloat(e.target.value) || 0 })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Réduction (%)</Label>
                    <Input
                      type="number"
                      value={pricingForm.quarterlyDiscount}
                      onChange={(e) => setPricingForm({ ...pricingForm, quarterlyDiscount: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                </div>
              )}
            </div>
            
            {/* Yearly */}
            <div className="p-4 border rounded-lg space-y-3">
              <div className="flex items-center justify-between">
                <Label className="font-semibold">Annuel (12 mois)</Label>
                <Switch
                  checked={pricingForm.yearlyEnabled}
                  onCheckedChange={(checked) => setPricingForm({ ...pricingForm, yearlyEnabled: checked })}
                />
              </div>
              {pricingForm.yearlyEnabled && (
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Prix (XOF)</Label>
                    <Input
                      type="number"
                      value={pricingForm.yearlyPrice}
                      onChange={(e) => setPricingForm({ ...pricingForm, yearlyPrice: parseFloat(e.target.value) || 0 })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Réduction (%)</Label>
                    <Input
                      type="number"
                      value={pricingForm.yearlyDiscount}
                      onChange={(e) => setPricingForm({ ...pricingForm, yearlyDiscount: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                </div>
              )}
            </div>
            
            {/* Limits */}
            <div className="p-4 border rounded-lg space-y-3">
              <Label className="font-semibold">Limites du Plan</Label>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label className="text-xs">Produits max</Label>
                  <Input
                    type="number"
                    value={pricingForm.maxProducts}
                    onChange={(e) => setPricingForm({ ...pricingForm, maxProducts: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Mouvements/mois</Label>
                  <Input
                    type="number"
                    value={pricingForm.maxMovements}
                    onChange={(e) => setPricingForm({ ...pricingForm, maxMovements: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Alertes max</Label>
                  <Input
                    type="number"
                    value={pricingForm.maxAlerts}
                    onChange={(e) => setPricingForm({ ...pricingForm, maxAlerts: parseInt(e.target.value) || 0 })}
                  />
                </div>
              </div>
            </div>
            
            {/* Popular */}
            <div className="flex items-center justify-between">
              <Label>Marquer comme "Populaire"</Label>
              <Switch
                checked={pricingForm.isPopular}
                onCheckedChange={(checked) => setPricingForm({ ...pricingForm, isPopular: checked })}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPricingModal(false)}>
              Annuler
            </Button>
            <Button onClick={savePricing} disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
              Sauvegarder
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* SETTINGS MODAL */}
      <Dialog open={showSettingsModal} onOpenChange={setShowSettingsModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Paramètres Administrateur</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Email administrateur</Label>
              <Input
                type="email"
                value={settingsForm.email}
                onChange={(e) => setSettingsForm({ ...settingsForm, email: e.target.value })}
                placeholder="admin@example.com"
              />
              <p className="text-xs text-muted-foreground">
                Cet email sera utilisé pour l'envoi des vouchers via Outlook
              </p>
            </div>
            
            <Alert>
              <Mail className="h-4 w-4" />
              <AlertTitle>Configuration Email</AlertTitle>
              <AlertDescription className="text-xs">
                Les emails sont envoyés via votre client Outlook local. 
                Cliquez sur "Email" après génération d'un voucher pour ouvrir Outlook avec un message pré-rédigé.
              </AlertDescription>
            </Alert>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSettingsModal(false)}>
              Annuler
            </Button>
            <Button onClick={saveSettings} disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
              Sauvegarder
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* PAYMENT METHOD MODAL */}
      <Dialog open={showMethodModal} onOpenChange={setShowMethodModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingMethod ? 'Modifier' : 'Ajouter'} une méthode
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Type</Label>
                <Select
                  value={methodForm.type}
                  onValueChange={(value) => setMethodForm({ ...methodForm, type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="MTN">MTN Mobile Money</SelectItem>
                    <SelectItem value="CELTIIS">Celtiis Money</SelectItem>
                    <SelectItem value="CRYPTO">Cryptomonnaie</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Nom *</Label>
                <Input
                  value={methodForm.name}
                  onChange={(e) => setMethodForm({ ...methodForm, name: e.target.value })}
                  placeholder="Ex: MTN Mobile Money Principal"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Nom du compte</Label>
                <Input
                  value={methodForm.accountName}
                  onChange={(e) => setMethodForm({ ...methodForm, accountName: e.target.value })}
                  placeholder="Nom du titulaire"
                />
              </div>
              
              <div className="space-y-2">
                <Label>Numéro/Adresse *</Label>
                <Input
                  value={methodForm.accountNumber}
                  onChange={(e) => setMethodForm({ ...methodForm, accountNumber: e.target.value })}
                  placeholder="Numéro ou adresse wallet"
                />
              </div>
            </div>
            
            {methodForm.type === 'CRYPTO' && (
              <div className="space-y-2">
                <Label>Réseau</Label>
                <Input
                  value={methodForm.network}
                  onChange={(e) => setMethodForm({ ...methodForm, network: e.target.value })}
                  placeholder="Ex: Base, Ethereum, TRC20..."
                />
              </div>
            )}
            
            <div className="space-y-2">
              <Label>Instructions</Label>
              <Textarea
                value={methodForm.instructions}
                onChange={(e) => setMethodForm({ ...methodForm, instructions: e.target.value })}
                placeholder="Instructions pour le client..."
                rows={3}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label>Visible pour les clients</Label>
              <Switch
                checked={methodForm.isVisible}
                onCheckedChange={(checked) => setMethodForm({ ...methodForm, isVisible: checked })}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowMethodModal(false)}>
              Annuler
            </Button>
            <Button onClick={saveMethod} disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
              {editingMethod ? 'Mettre à jour' : 'Créer'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { 
  CreditCard, CheckCircle, Clock, 
  Copy, Ticket, Key, Zap, Star,
  ArrowUpRight, Package, BarChart3, Bell, Smartphone,
  Globe, Wallet, Coins, Send, Loader2,
  Sparkles, Users, ChevronRight, AlertCircle,
  Menu, X, Shield, ExternalLink, Gift
} from 'lucide-react';
import { toast } from 'sonner';
import { AdminPanel } from '@/components/admin-panel';
import { ContactForm } from '@/components/contact-form';

// Types
interface PaymentMethod {
  id: string;
  type: string;
  name: string;
  accountName?: string;
  accountNumber?: string;
  network?: string;
  instructions?: string;
  isActive: boolean;
  isVisible: boolean;
}

interface PricingPlan {
  plan: string;
  monthlyPrice: number;
  monthlyEnabled: boolean;
  quarterlyPrice: number;
  quarterlyEnabled: boolean;
  quarterlyDiscount: number;
  yearlyPrice: number;
  yearlyEnabled: boolean;
  yearlyDiscount: number;
  features: string[];
  isPopular: boolean;
  maxProducts: number;
  maxMovements: number;
  maxAlerts: number;
}

// Default data for immediate display
const DEFAULT_METHODS: PaymentMethod[] = [
  {
    id: 'mtn-default',
    type: 'MTN',
    name: 'MTN Mobile Money',
    accountName: 'MTN Payment',
    accountNumber: '0152877272',
    isActive: true,
    isVisible: true,
    instructions: 'Envoyez le montant au numéro MTN indiqué. Inscrivez la référence de la transaction dans le formulaire.'
  },
  {
    id: 'celtiis-default',
    type: 'CELTIIS',
    name: 'Celtiis Money',
    accountName: 'Celtiis Payment',
    accountNumber: '0140738501',
    isActive: true,
    isVisible: true,
    instructions: 'Envoyez le montant au numéro Celtiis indiqué. Inscrivez la référence de la transaction dans le formulaire.'
  },
  {
    id: 'usdc-default',
    type: 'CRYPTO',
    name: 'USDC (Base Network)',
    accountName: 'USDC Base',
    accountNumber: '0x742d35Cc6634C0532925a3b844Bc9e7595f8C2dF',
    network: 'Base',
    isActive: true,
    isVisible: true,
    instructions: 'Envoyez exactement le montant en USDC sur le réseau Base. Copiez le hash de la transaction.'
  },
  {
    id: 'pi-default',
    type: 'CRYPTO',
    name: 'Pi Network',
    accountName: 'Pi Wallet',
    accountNumber: 'pi_network_official_wallet',
    network: 'Pi Network',
    isActive: true,
    isVisible: true,
    instructions: 'Envoyez le montant en Pi via le wallet Pi Network. Notez votre username Pi comme référence.'
  }
];

const DEFAULT_PRICING: PricingPlan[] = [
  {
    plan: 'STARTER',
    monthlyPrice: 5000,
    monthlyEnabled: true,
    quarterlyPrice: 13500,
    quarterlyEnabled: true,
    quarterlyDiscount: 10,
    yearlyPrice: 48000,
    yearlyEnabled: true,
    yearlyDiscount: 20,
    features: ['Jusqu\'à 10 produits', '100 mouvements/mois', '10 alertes stock', 'Support email', 'Export CSV'],
    isPopular: false,
    maxProducts: 10,
    maxMovements: 100,
    maxAlerts: 10
  },
  {
    plan: 'PRO',
    monthlyPrice: 15000,
    monthlyEnabled: true,
    quarterlyPrice: 40500,
    quarterlyEnabled: true,
    quarterlyDiscount: 10,
    yearlyPrice: 144000,
    yearlyEnabled: true,
    yearlyDiscount: 20,
    features: ['Jusqu\'à 50 produits', '500 mouvements/mois', '50 alertes stock', 'Alertes email illimitées', 'Export PDF & Excel', 'Support prioritaire', 'API Access'],
    isPopular: true,
    maxProducts: 50,
    maxMovements: 500,
    maxAlerts: 50
  },
  {
    plan: 'ENTERPRISE',
    monthlyPrice: 50000,
    monthlyEnabled: true,
    quarterlyPrice: 135000,
    quarterlyEnabled: true,
    quarterlyDiscount: 10,
    yearlyPrice: 480000,
    yearlyEnabled: true,
    yearlyDiscount: 20,
    features: ['Produits illimités', 'Mouvements illimités', 'Alertes illimitées', 'Alertes email & IA', 'Export avancé', 'Support 24/7', 'API illimitée', 'Marque personnalisée'],
    isPopular: false,
    maxProducts: 999999,
    maxMovements: 999999,
    maxAlerts: 999999
  }
];

const PLAN_COLORS: Record<string, string> = {
  STARTER: 'from-blue-500 to-cyan-500',
  PRO: 'from-purple-500 to-pink-500',
  ENTERPRISE: 'from-amber-500 to-orange-500'
};

const DURATIONS = [
  { id: 'MONTHLY', label: 'Mensuel', multiplier: 1 },
  { id: 'QUARTERLY', label: 'Trimestriel', multiplier: 3 },
  { id: 'YEARLY', label: 'Annuel', multiplier: 12 }
];

const FEATURES = [
  { icon: Package, title: 'Gestion Stock Avancée', description: 'Suivez vos stocks en temps réel avec alertes automatiques et prévisions IA.' },
  { icon: BarChart3, title: 'Analytics Puissants', description: 'Tableaux de bord interactifs et rapports détaillés pour des décisions éclairées.' },
  { icon: Bell, title: 'Alertes Intelligentes', description: 'Notifications automatiques quand le stock atteint le seuil critique.' },
  { icon: Globe, title: 'Multi-Devises', description: 'Gérez vos transactions en XOF, EUR, USD et cryptomonnaies.' },
  { icon: Smartphone, title: 'Mobile First', description: 'Interface responsive optimisée pour tous les appareils.' },
  { icon: Zap, title: 'Automatisation IA', description: 'Prévisions de stock et suggestions intelligentes basées sur l\'IA.' }
];

export default function Home() {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(DEFAULT_METHODS);
  const [pricingPlans, setPricingPlans] = useState<PricingPlan[]>(DEFAULT_PRICING);
  const [selectedPlan, setSelectedPlan] = useState<PricingPlan | null>(null);
  const [selectedDuration, setSelectedDuration] = useState<string>('MONTHLY');
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentForm, setPaymentForm] = useState({
    userEmail: '',
    userPhone: '',
    reference: '',
    notes: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    // Load data from API in background
    loadPricingData();
    loadPaymentMethods();
  }, []);

  const loadPricingData = async () => {
    try {
      const res = await fetch('/api/pricing');
      const data = await res.json();
      if (data.success && data.pricings?.length > 0) {
        setPricingPlans(data.pricings);
      }
    } catch {
      console.log('Using default pricing data');
    }
  };

  const loadPaymentMethods = async () => {
    try {
      const res = await fetch('/api/payments');
      const data = await res.json();
      if (data.success && data.methods?.length > 0) {
        setPaymentMethods(data.methods);
      }
    } catch {
      console.log('Using default payment methods');
    }
  };

  const getPriceForDuration = (plan: PricingPlan, duration: string): number => {
    switch (duration) {
      case 'QUARTERLY':
        return plan.quarterlyPrice;
      case 'YEARLY':
        return plan.yearlyPrice;
      default:
        return plan.monthlyPrice;
    }
  };

  const getDiscount = (plan: PricingPlan, duration: string): number => {
    switch (duration) {
      case 'QUARTERLY':
        return plan.quarterlyDiscount;
      case 'YEARLY':
        return plan.yearlyDiscount;
      default:
        return 0;
    }
  };

  const openPaymentModal = (plan: PricingPlan) => {
    setSelectedPlan(plan);
    setSelectedMethod(null);
    setPaymentForm({
      userEmail: '',
      userPhone: '',
      reference: '',
      notes: ''
    });
    setPaymentSuccess(false);
    setShowPaymentModal(true);
  };

  const submitPayment = async () => {
    if (!selectedPlan || !selectedMethod) {
      toast.error('Veuillez sélectionner un plan et une méthode de paiement');
      return;
    }
    
    if (!paymentForm.userEmail) {
      toast.error('Veuillez entrer votre email');
      return;
    }
    
    if (!paymentForm.reference) {
      toast.error('Veuillez entrer la référence de votre paiement');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const res = await fetch('/api/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: getPriceForDuration(selectedPlan, selectedDuration),
          currency: 'XOF',
          paymentMethod: selectedMethod.name,
          methodType: selectedMethod.type,
          reference: paymentForm.reference,
          notes: paymentForm.notes,
          requestedPlan: selectedPlan.plan,
          duration: selectedDuration,
          userEmail: paymentForm.userEmail,
          userPhone: paymentForm.userPhone
        })
      });
      
      const data = await res.json();
      
      if (data.success) {
        setPaymentSuccess(true);
        toast.success('Paiement soumis ! Vous recevrez votre licence après confirmation.');
      } else {
        toast.error(data.error || 'Erreur lors de la soumission');
      }
    } catch {
      toast.error('Erreur de connexion');
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copié dans le presse-papier !');
  };

  const getMethodIcon = (type: string) => {
    switch (type) {
      case 'MTN': return <Smartphone className="h-5 w-5 text-yellow-600" />;
      case 'CELTIIS': return <Smartphone className="h-5 w-5 text-green-600" />;
      case 'CRYPTO': return <Coins className="h-5 w-5 text-orange-500" />;
      default: return <Wallet className="h-5 w-5" />;
    }
  };

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    setIsMenuOpen(false);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl">
                <Package className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  StockPro
                </h1>
                <p className="text-xs text-slate-500">Gestion intelligente</p>
              </div>
            </div>
            
            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-6">
              {[
                { id: 'home', label: 'Accueil' },
                { id: 'features', label: 'Fonctionnalités' },
                { id: 'pricing', label: 'Tarifs' },
                { id: 'payment', label: 'Paiement' },
                { id: 'support', label: 'Support' },
                { id: 'admin', label: 'Admin' }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`text-sm font-medium transition-colors ${
                    activeSection === item.id 
                      ? 'text-purple-600' 
                      : 'text-slate-600 hover:text-purple-600'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>
            
            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 rounded-lg hover:bg-slate-100"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
          
          {/* Mobile Nav */}
          {isMenuOpen && (
            <nav className="md:hidden mt-4 pb-4 border-t border-slate-200 pt-4">
              <div className="flex flex-col gap-2">
                {[
                  { id: 'home', label: 'Accueil' },
                  { id: 'features', label: 'Fonctionnalités' },
                  { id: 'pricing', label: 'Tarifs' },
                  { id: 'payment', label: 'Paiement' },
                  { id: 'support', label: 'Support' },
                  { id: 'admin', label: 'Admin' }
                ].map(item => (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className={`text-left px-4 py-2 rounded-lg transition-colors ${
                      activeSection === item.id 
                        ? 'bg-purple-50 text-purple-600' 
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </nav>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 via-pink-500/5 to-orange-500/5" />
        <div className="absolute top-20 right-20 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto px-4 py-20 relative">
          <div className="text-center max-w-3xl mx-auto space-y-8">
            <Badge className="px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
              <Sparkles className="h-4 w-4 mr-2" />
              Nouvelle version 2.0 disponible
            </Badge>
            
            <h1 className="text-4xl md:text-6xl font-bold leading-tight">
              Gérez votre{' '}
              <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                stock
              </span>{' '}
              comme un pro
            </h1>
            
            <p className="text-lg md:text-xl text-slate-600 max-w-2xl mx-auto">
              Solution complète de gestion de stock avec alertes intelligentes, 
              facturation et analytics avancés. Simple, puissant, accessible.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-6 text-lg"
                onClick={() => scrollToSection('pricing')}
              >
                <Zap className="h-5 w-5 mr-2" />
                Commencer maintenant
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="px-8 py-6 text-lg"
                onClick={() => scrollToSection('features')}
              >
                En savoir plus
                <ArrowUpRight className="h-5 w-5 ml-2" />
              </Button>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12">
              {[
                { value: '500+', label: 'Clients actifs' },
                { value: '10K+', label: 'Produits gérés' },
                { value: '99.9%', label: 'Disponibilité' },
                { value: '24/7', label: 'Support' }
              ].map((stat, i) => (
                <div key={i} className="p-4 bg-white rounded-xl shadow-sm border border-slate-100">
                  <p className="text-2xl font-bold text-purple-600">{stat.value}</p>
                  <p className="text-sm text-slate-500">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4" variant="secondary">Fonctionnalités</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Tout ce dont vous avez besoin
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Une suite complète d'outils pour gérer efficacement votre activité
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map((feature, i) => (
              <Card key={i} className="group hover:shadow-lg transition-all duration-300 border-slate-200 hover:border-purple-300">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <feature.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-slate-600 text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-gradient-to-b from-slate-50 to-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4" variant="secondary">Tarifs</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Des plans pour tous les besoins
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto mb-6">
              Choisissez le plan adapté à votre activité. Paiements flexibles via Mobile Money ou Crypto.
            </p>
            
            {/* Duration Selector */}
            <div className="flex items-center justify-center gap-2 bg-slate-100 p-1 rounded-lg w-fit mx-auto">
              {DURATIONS.map(dur => (
                <button
                  key={dur.id}
                  onClick={() => setSelectedDuration(dur.id)}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                    selectedDuration === dur.id 
                      ? 'bg-white shadow text-purple-600' 
                      : 'text-slate-600 hover:text-purple-600'
                  }`}
                >
                  {dur.label}
                  {dur.id !== 'MONTHLY' && (
                    <Badge variant="secondary" className="ml-2 text-xs bg-green-100 text-green-700">
                      -{dur.id === 'QUARTERLY' ? '10%' : '20%'}
                    </Badge>
                  )}
                </button>
              ))}
            </div>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {pricingPlans.map((plan) => {
              const price = getPriceForDuration(plan, selectedDuration);
              const discount = getDiscount(plan, selectedDuration);
              const isDurationEnabled = selectedDuration === 'MONTHLY' 
                ? plan.monthlyEnabled 
                : selectedDuration === 'QUARTERLY' 
                  ? plan.quarterlyEnabled 
                  : plan.yearlyEnabled;
              
              if (!isDurationEnabled) return null;
              
              return (
                <Card 
                  key={plan.plan}
                  className={`relative overflow-hidden transition-all ${
                    plan.isPopular 
                      ? 'border-2 border-purple-500 shadow-xl scale-105' 
                      : 'border-slate-200'
                  }`}
                >
                  {plan.isPopular && (
                    <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold py-1 text-center">
                      <Star className="h-3 w-3 inline mr-1" />
                      PLUS POPULAIRE
                    </div>
                  )}
                  
                  <CardHeader className={plan.isPopular ? 'pt-8' : ''}>
                    <div className={`w-12 h-12 bg-gradient-to-br ${PLAN_COLORS[plan.plan]} rounded-xl flex items-center justify-center mb-4`}>
                      <Zap className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="text-2xl">{plan.plan}</CardTitle>
                    <CardDescription>
                      <span className="text-3xl font-bold text-slate-900">
                        {price.toLocaleString()}
                      </span>
                      <span className="text-slate-600"> XOF</span>
                      {selectedDuration !== 'YEARLY' && (
                        <span className="text-slate-400"> / {selectedDuration === 'QUARTERLY' ? '3 mois' : 'mois'}</span>
                      )}
                      {discount > 0 && (
                        <Badge variant="secondary" className="ml-2 bg-green-100 text-green-700">
                          -{discount}%
                        </Badge>
                      )}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <ul className="space-y-3">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-center gap-2 text-sm">
                          <CheckCircle className="h-4 w-4 text-green-500 shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    {/* Plan limits */}
                    <div className="mt-4 pt-4 border-t text-xs text-muted-foreground space-y-1">
                      <p>📊 Produits: {plan.maxProducts === 999999 ? 'Illimité' : plan.maxProducts}</p>
                      <p>📦 Mouvements: {plan.maxMovements === 999999 ? 'Illimité' : plan.maxMovements}/mois</p>
                      <p>🔔 Alertes: {plan.maxAlerts === 999999 ? 'Illimité' : plan.maxAlerts}</p>
                    </div>
                  </CardContent>
                  
                  <CardFooter>
                    <Button 
                      className={`w-full ${
                        plan.isPopular 
                          ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700' 
                          : ''
                      }`}
                      variant={plan.isPopular ? 'default' : 'outline'}
                      onClick={() => openPaymentModal(plan)}
                    >
                      <CreditCard className="h-4 w-4 mr-2" />
                      Souscrire
                    </Button>
                  </CardFooter>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Payment Methods Section */}
      <section id="payment" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4" variant="secondary">Moyens de paiement</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Paiements flexibles & sécurisés
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Choisissez parmi nos différents moyens de paiement acceptés
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {paymentMethods.map((method) => (
              <Card key={method.id} className="hover:shadow-lg transition-all border-slate-200">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    {getMethodIcon(method.type)}
                    <div>
                      <h3 className="font-semibold">{method.name}</h3>
                      {method.network && (
                        <Badge variant="outline" className="text-xs mt-1">{method.network}</Badge>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-500">Compte:</span>
                      <code className="flex-1 text-sm bg-slate-100 px-2 py-1 rounded font-mono text-xs break-all">
                        {method.accountNumber}
                      </code>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0 shrink-0"
                        onClick={() => copyToClipboard(method.accountNumber || '')}
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    
                    {method.accountName && (
                      <p className="text-xs text-slate-500">Nom: {method.accountName}</p>
                    )}
                  </div>
                  
                  {method.instructions && (
                    <p className="text-xs text-slate-500 mt-3 p-2 bg-slate-50 rounded">
                      {method.instructions}
                    </p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Support Section */}
      <section id="support" className="py-20 bg-gradient-to-b from-slate-50 to-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4" variant="secondary">Support</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Besoin d'aide ?
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Notre équipe est disponible pour répondre à vos questions
            </p>
          </div>
          
          <div className="max-w-xl mx-auto">
            <ContactForm />
          </div>
        </div>
      </section>

      {/* Admin Section */}
      <section id="admin" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4" variant="secondary">Administration</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Espace Administrateur
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Gérez votre plateforme, les paiements et les abonnements
            </p>
          </div>
          
          <div className="max-w-6xl mx-auto">
            <AdminPanel />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl">
                  <Package className="h-5 w-5 text-white" />
                </div>
                <span className="text-xl font-bold">StockPro</span>
              </div>
              <p className="text-slate-400 text-sm">
                Solution professionnelle de gestion de stock pour les entreprises modernes.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Liens rapides</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><button onClick={() => scrollToSection('features')} className="hover:text-white transition">Fonctionnalités</button></li>
                <li><button onClick={() => scrollToSection('pricing')} className="hover:text-white transition">Tarifs</button></li>
                <li><button onClick={() => scrollToSection('payment')} className="hover:text-white transition">Paiement</button></li>
                <li><button onClick={() => scrollToSection('support')} className="hover:text-white transition">Support</button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Paiement</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li className="flex items-center gap-2"><Smartphone className="h-4 w-4" /> MTN Mobile Money</li>
                <li className="flex items-center gap-2"><Smartphone className="h-4 w-4" /> Celtiis Money</li>
                <li className="flex items-center gap-2"><Coins className="h-4 w-4" /> USDC (Base)</li>
                <li className="flex items-center gap-2"><Gift className="h-4 w-4" /> Pi Network</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li>Cotonou, Bénin</li>
                <li>+229 0152877272</li>
                <li>contact@stockpro.bj</li>
              </ul>
            </div>
          </div>
          
          <Separator className="my-8 bg-slate-800" />
          
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-slate-400">
            <p>© 2024 StockPro. Tous droits réservés.</p>
            <p>Fait avec ❤️ au Bénin</p>
          </div>
        </div>
      </footer>

      {/* Payment Modal */}
      <Dialog open={showPaymentModal} onOpenChange={setShowPaymentModal}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Souscription {selectedPlan?.plan}
            </DialogTitle>
            <DialogDescription>
              Montant: <span className="font-bold text-purple-600">
                {selectedPlan && getPriceForDuration(selectedPlan, selectedDuration).toLocaleString()} XOF
              </span>
              <span className="text-slate-500">
                {' '}({selectedDuration === 'MONTHLY' ? '1 mois' : selectedDuration === 'QUARTERLY' ? '3 mois' : '12 mois'})
              </span>
            </DialogDescription>
          </DialogHeader>
          
          {paymentSuccess ? (
            <div className="py-8 text-center space-y-4">
              <div className="mx-auto p-4 bg-green-100 rounded-full w-fit">
                <CheckCircle className="h-12 w-12 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-green-700">Paiement soumis !</h3>
              <p className="text-slate-600">
                Votre demande a été enregistrée. Vous recevrez votre code de licence 
                par email après confirmation par notre équipe (sous 24-48h).
              </p>
              <Button onClick={() => setShowPaymentModal(false)}>
                Fermer
              </Button>
            </div>
          ) : (
            <>
              {/* Step 1: Select Payment Method */}
              {!selectedMethod && (
                <div className="space-y-4">
                  <Label>Choisissez votre moyen de paiement</Label>
                  <div className="space-y-2">
                    {paymentMethods.map((method) => (
                      <button
                        key={method.id}
                        onClick={() => setSelectedMethod(method)}
                        className="w-full p-4 border rounded-lg hover:border-purple-500 hover:bg-purple-50 transition-all flex items-center gap-4 text-left"
                      >
                        {getMethodIcon(method.type)}
                        <div className="flex-1">
                          <p className="font-medium">{method.name}</p>
                          <p className="text-xs text-slate-500">{method.accountNumber}</p>
                        </div>
                        <ChevronRight className="h-4 w-4 text-slate-400" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Step 2: Payment Details */}
              {selectedMethod && (
                <div className="space-y-4">
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Instructions</AlertTitle>
                    <AlertDescription className="text-sm">
                      {selectedMethod.instructions || `Envoyez le montant exact au numéro ${selectedMethod.accountNumber}`}
                    </AlertDescription>
                  </Alert>
                  
                  <div className="p-4 bg-slate-50 rounded-lg space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-500">Montant:</span>
                      <span className="font-bold">{selectedPlan && getPriceForDuration(selectedPlan, selectedDuration).toLocaleString()} XOF</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-500">Destination:</span>
                      <div className="flex items-center gap-2">
                        <code className="text-sm bg-white px-2 py-1 rounded font-mono text-xs">
                          {selectedMethod.accountNumber}
                        </code>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0"
                          onClick={() => copyToClipboard(selectedMethod.accountNumber || '')}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="userEmail">Votre email *</Label>
                      <Input
                        id="userEmail"
                        type="email"
                        placeholder="votre@email.com"
                        value={paymentForm.userEmail}
                        onChange={(e) => setPaymentForm({ ...paymentForm, userEmail: e.target.value })}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="userPhone">Téléphone (optionnel)</Label>
                      <Input
                        id="userPhone"
                        placeholder="+229 XX XX XX XX"
                        value={paymentForm.userPhone}
                        onChange={(e) => setPaymentForm({ ...paymentForm, userPhone: e.target.value })}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="reference">Référence de transaction *</Label>
                      <Input
                        id="reference"
                        placeholder="ID transaction, hash ou code"
                        value={paymentForm.reference}
                        onChange={(e) => setPaymentForm({ ...paymentForm, reference: e.target.value })}
                      />
                      <p className="text-xs text-slate-500 mt-1">
                        Entrez l'ID de transaction Mobile Money ou le hash crypto
                      </p>
                    </div>
                    
                    <div>
                      <Label htmlFor="notes">Notes (optionnel)</Label>
                      <Textarea
                        id="notes"
                        placeholder="Informations supplémentaires..."
                        value={paymentForm.notes}
                        onChange={(e) => setPaymentForm({ ...paymentForm, notes: e.target.value })}
                        rows={2}
                      />
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={() => setSelectedMethod(null)}
                      className="flex-1"
                    >
                      Retour
                    </Button>
                    <Button
                      onClick={submitPayment}
                      disabled={isSubmitting}
                      className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Envoi...
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4 mr-2" />
                          Soumettre
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

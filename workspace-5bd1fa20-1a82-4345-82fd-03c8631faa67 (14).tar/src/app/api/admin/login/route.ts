import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const { password } = await request.json();
    
    if (!password) {
      return NextResponse.json({ 
        success: false, 
        error: 'Mot de passe requis' 
      }, { status: 400 });
    }
    
    // Check if admin settings exist
    let adminSettings = await db.adminSettings.findFirst();
    
    // If no admin settings, create default
    if (!adminSettings) {
      adminSettings = await db.adminSettings.create({
        data: {
          id: 'default',
          adminPassword: 'admin123',
          requireAdminApproval: true,
          autoGenerateVoucher: false
        }
      });
    }
    
    // Verify password
    if (password === adminSettings.adminPassword) {
      return NextResponse.json({ 
        success: true,
        message: 'Connexion réussie'
      });
    }
    
    return NextResponse.json({ 
      success: false, 
      error: 'Mot de passe incorrect' 
    }, { status: 401 });
    
  } catch (error) {
    console.error('Erreur login:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur serveur' 
    }, { status: 500 });
  }
}

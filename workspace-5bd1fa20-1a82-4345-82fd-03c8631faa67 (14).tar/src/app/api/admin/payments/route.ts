import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Generate unique voucher code
function generateVoucherCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 4; i++) {
    if (i > 0) code += '-';
    for (let j = 0; j < 4; j++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
  }
  return code;
}

// Get duration in days
function getDurationInDays(duration: string): number {
  switch (duration) {
    case 'QUARTERLY': return 90;
    case 'YEARLY': return 365;
    default: return 30;
  }
}

// GET - List all payments
export async function GET() {
  try {
    const payments = await db.payment.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        voucher: true
      }
    });
    
    return NextResponse.json({ 
      success: true, 
      payments 
    });
  } catch (error) {
    console.error('Erreur récupération paiements:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur serveur' 
    }, { status: 500 });
  }
}

// POST - Confirm or reject payment
export async function POST(request: Request) {
  try {
    const data = await request.json();
    const { paymentId, action, plan, duration, adminNotes } = data;
    
    if (!paymentId || !action) {
      return NextResponse.json({ 
        success: false, 
        error: 'Données manquantes' 
      }, { status: 400 });
    }
    
    const payment = await db.payment.findUnique({
      where: { id: paymentId }
    });
    
    if (!payment) {
      return NextResponse.json({ 
        success: false, 
        error: 'Paiement non trouvé' 
      }, { status: 404 });
    }
    
    if (action === 'confirm') {
      // Generate voucher
      const voucherCode = generateVoucherCode();
      const durationDays = getDurationInDays(duration || 'MONTHLY');
      
      // Create voucher and update payment in transaction
      const result = await db.$transaction(async (tx) => {
        const voucher = await tx.voucher.create({
          data: {
            code: voucherCode,
            plan: plan || payment.requestedPlan || 'STARTER',
            duration: durationDays,
            status: 'ACTIVE',
            paymentId,
            expiresAt: new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000)
          }
        });
        
        const updatedPayment = await tx.payment.update({
          where: { id: paymentId },
          data: {
            status: 'CONFIRMED',
            confirmedAt: new Date(),
            adminNotes,
            requestedPlan: plan || payment.requestedPlan
          }
        });
        
        // Log activity
        await tx.activityLog.create({
          data: {
            action: 'PAYMENT_CONFIRMED',
            entityType: 'PAYMENT',
            entityId: paymentId,
            details: JSON.stringify({
              amount: payment.amount,
              plan: plan || payment.requestedPlan,
              voucherCode,
              duration: durationDays
            })
          }
        });
        
        return { voucher, payment: updatedPayment };
      });
      
      return NextResponse.json({ 
        success: true,
        message: 'Paiement confirmé et licence générée',
        voucher: {
          code: result.voucher.code,
          plan: result.voucher.plan,
          duration: result.voucher.duration
        }
      });
      
    } else if (action === 'reject') {
      await db.$transaction(async (tx) => {
        await tx.payment.update({
          where: { id: paymentId },
          data: {
            status: 'FAILED',
            adminNotes
          }
        });
        
        await tx.activityLog.create({
          data: {
            action: 'PAYMENT_REJECTED',
            entityType: 'PAYMENT',
            entityId: paymentId,
            details: JSON.stringify({
              amount: payment.amount,
              reason: adminNotes
            })
          }
        });
      });
      
      return NextResponse.json({ 
        success: true,
        message: 'Paiement rejeté'
      });
    }
    
    return NextResponse.json({ 
      success: false, 
      error: 'Action invalide' 
    }, { status: 400 });
    
  } catch (error) {
    console.error('Erreur traitement paiement:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur serveur' 
    }, { status: 500 });
  }
}

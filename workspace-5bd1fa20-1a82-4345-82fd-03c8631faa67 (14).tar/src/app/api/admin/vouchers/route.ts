import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Generate unique voucher code
function generateVoucherCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 4; i++) {
    if (i > 0) code += '-';
    for (let j = 0; j < 4; j++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
  }
  return code;
}

// GET - List all vouchers
export async function GET() {
  try {
    const vouchers = await db.voucher.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        payment: {
          select: {
            amount: true,
            currency: true,
            userEmail: true,
            userPhone: true
          }
        }
      }
    });
    
    return NextResponse.json({ 
      success: true, 
      vouchers 
    });
  } catch (error) {
    console.error('Erreur récupération vouchers:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur serveur' 
    }, { status: 500 });
  }
}

// POST - Create manual voucher
export async function POST(request: Request) {
  try {
    const data = await request.json();
    const { plan, duration, notes } = data;
    
    const voucherCode = generateVoucherCode();
    const voucherDuration = duration || 30;
    
    const voucher = await db.voucher.create({
      data: {
        code: voucherCode,
        plan: plan || 'STARTER',
        duration: voucherDuration,
        status: 'ACTIVE',
        expiresAt: new Date(Date.now() + voucherDuration * 24 * 60 * 60 * 1000),
        notes
      }
    });
    
    await db.activityLog.create({
      data: {
        action: 'VOUCHER_CREATED',
        entityType: 'VOUCHER',
        entityId: voucher.id,
        details: JSON.stringify({
          code: voucherCode,
          plan,
          manuallyCreated: true
        })
      }
    });
    
    return NextResponse.json({ 
      success: true,
      voucher,
      message: 'Voucher créé avec succès'
    });
    
  } catch (error) {
    console.error('Erreur création voucher:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur lors de la création' 
    }, { status: 500 });
  }
}

// DELETE - Delete voucher
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ 
        success: false, 
        error: 'ID requis' 
      }, { status: 400 });
    }
    
    await db.voucher.delete({
      where: { id }
    });
    
    return NextResponse.json({ 
      success: true,
      message: 'Voucher supprimé'
    });
    
  } catch (error) {
    console.error('Erreur suppression:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur lors de la suppression' 
    }, { status: 500 });
  }
}

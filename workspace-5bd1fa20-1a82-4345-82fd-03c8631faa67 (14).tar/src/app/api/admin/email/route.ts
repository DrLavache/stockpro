import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get admin email configuration
export async function GET() {
  try {
    let email = await db.adminEmail.findFirst({
      where: { isActive: true }
    });
    
    // If no email exists, create default
    if (!email) {
      email = await db.adminEmail.create({
        data: {
          email: 'icholababoukari@outlook.com',
          isActive: true
        }
      });
    }
    
    return NextResponse.json({ 
      success: true, 
      email 
    });
  } catch (error) {
    console.error('Erreur récupération email:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur serveur' 
    }, { status: 500 });
  }
}

// POST - Update admin email
export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    // Deactivate all existing emails
    await db.adminEmail.updateMany({
      where: { isActive: true },
      data: { isActive: false }
    });
    
    // Create or update the email
    const email = await db.adminEmail.upsert({
      where: { email: data.email },
      update: { isActive: true },
      create: {
        email: data.email,
        isActive: true
      }
    });
    
    return NextResponse.json({ 
      success: true, 
      email,
      message: 'Email mis à jour'
    });
  } catch (error) {
    console.error('Erreur mise à jour email:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur lors de la mise à jour' 
    }, { status: 500 });
  }
}

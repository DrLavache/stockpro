import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List all payment methods
export async function GET() {
  try {
    const methods = await db.paymentMethod.findMany({
      orderBy: [
        { type: 'asc' },
        { createdAt: 'asc' }
      ]
    });
    
    return NextResponse.json({ 
      success: true, 
      methods 
    });
  } catch (error) {
    console.error('Erreur récupération méthodes:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur serveur' 
    }, { status: 500 });
  }
}

// POST - Create new payment method
export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    const method = await db.paymentMethod.create({
      data: {
        type: data.type,
        name: data.name,
        accountName: data.accountName || null,
        accountNumber: data.accountNumber || null,
        network: data.network || null,
        instructions: data.instructions || null,
        isVisible: data.isVisible || false,
        isActive: true
      }
    });
    
    return NextResponse.json({ 
      success: true, 
      method,
      message: 'Méthode créée avec succès'
    });
  } catch (error) {
    console.error('Erreur création méthode:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur lors de la création' 
    }, { status: 500 });
  }
}

// PUT - Update payment method
export async function PUT(request: Request) {
  try {
    const data = await request.json();
    
    if (!data.id) {
      return NextResponse.json({ 
        success: false, 
        error: 'ID requis' 
      }, { status: 400 });
    }
    
    const method = await db.paymentMethod.update({
      where: { id: data.id },
      data: {
        type: data.type,
        name: data.name,
        accountName: data.accountName || null,
        accountNumber: data.accountNumber || null,
        network: data.network || null,
        instructions: data.instructions || null,
        isVisible: data.isVisible,
        isActive: data.isActive ?? true
      }
    });
    
    return NextResponse.json({ 
      success: true, 
      method,
      message: 'Méthode mise à jour'
    });
  } catch (error) {
    console.error('Erreur mise à jour:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur lors de la mise à jour' 
    }, { status: 500 });
  }
}

// DELETE - Remove payment method
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ 
        success: false, 
        error: 'ID requis' 
      }, { status: 400 });
    }
    
    await db.paymentMethod.delete({
      where: { id }
    });
    
    return NextResponse.json({ 
      success: true,
      message: 'Méthode supprimée'
    });
  } catch (error) {
    console.error('Erreur suppression:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur lors de la suppression' 
    }, { status: 500 });
  }
}

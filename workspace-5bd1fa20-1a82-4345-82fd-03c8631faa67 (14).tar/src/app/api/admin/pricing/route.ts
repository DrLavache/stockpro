import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get all pricing configurations
export async function GET() {
  try {
    let pricings = await db.pricingConfig.findMany({
      orderBy: { displayOrder: 'asc' }
    });
    
    // If no pricing exists, create defaults
    if (pricings.length === 0) {
      pricings = await db.pricingConfig.createMany({
        data: [
          {
            plan: 'STARTER',
            monthlyPrice: 5000,
            quarterlyPrice: 13500,
            quarterlyDiscount: 10,
            yearlyPrice: 48000,
            yearlyDiscount: 20,
            features: JSON.stringify([
              'Jusqu\'à 10 produits',
              '100 mouvements/mois',
              '10 alertes stock',
              'Support email',
              'Export CSV'
            ]),
            isActive: true,
            isPopular: false,
            displayOrder: 1
          },
          {
            plan: 'PRO',
            monthlyPrice: 15000,
            quarterlyPrice: 40500,
            quarterlyDiscount: 10,
            yearlyPrice: 144000,
            yearlyDiscount: 20,
            features: JSON.stringify([
              'Jusqu\'à 50 produits',
              '500 mouvements/mois',
              '50 alertes stock',
              'Alertes email illimitées',
              'Export PDF & Excel',
              'Support prioritaire',
              'API Access'
            ]),
            isActive: true,
            isPopular: true,
            displayOrder: 2
          },
          {
            plan: 'ENTERPRISE',
            monthlyPrice: 50000,
            quarterlyPrice: 135000,
            quarterlyDiscount: 10,
            yearlyPrice: 480000,
            yearlyDiscount: 20,
            features: JSON.stringify([
              'Produits illimités',
              'Mouvements illimités',
              'Alertes illimitées',
              'Alertes email & IA',
              'Export avancé',
              'Support 24/7',
              'API illimitée',
              'Marque personnalisée'
            ]),
            isActive: true,
            isPopular: false,
            displayOrder: 3
          }
        ]
      });
      
      pricings = await db.pricingConfig.findMany({
        orderBy: { displayOrder: 'asc' }
      });
    }
    
    return NextResponse.json({ 
      success: true, 
      pricings: pricings.map(p => ({
        ...p,
        features: p.features ? JSON.parse(p.features) : []
      }))
    });
  } catch (error) {
    console.error('Erreur récupération pricing:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur serveur' 
    }, { status: 500 });
  }
}

// POST - Update pricing configuration
export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    const pricing = await db.pricingConfig.update({
      where: { plan: data.plan },
      data: {
        monthlyPrice: data.monthlyPrice,
        monthlyEnabled: data.monthlyEnabled ?? true,
        quarterlyPrice: data.quarterlyPrice,
        quarterlyEnabled: data.quarterlyEnabled ?? true,
        quarterlyDiscount: data.quarterlyDiscount || 10,
        yearlyPrice: data.yearlyPrice,
        yearlyEnabled: data.yearlyEnabled ?? true,
        yearlyDiscount: data.yearlyDiscount || 20,
        features: data.features ? JSON.stringify(data.features) : null,
        isActive: data.isActive ?? true,
        isPopular: data.isPopular ?? false,
        displayOrder: data.displayOrder || 0
      }
    });
    
    return NextResponse.json({ 
      success: true, 
      pricing: {
        ...pricing,
        features: pricing.features ? JSON.parse(pricing.features) : []
      },
      message: 'Prix mis à jour'
    });
  } catch (error) {
    console.error('Erreur mise à jour pricing:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur lors de la mise à jour' 
    }, { status: 500 });
  }
}

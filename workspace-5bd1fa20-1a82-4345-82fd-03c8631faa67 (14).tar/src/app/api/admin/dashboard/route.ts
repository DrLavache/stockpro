import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Dashboard stats for admin
export async function GET() {
  try {
    // Get current subscription
    const subscription = await db.subscription.findFirst({
      orderBy: { createdAt: 'desc' }
    });
    
    // Get counts
    const [
      productsCount,
      movementsCount,
      alertsCount,
      paymentsPending,
      paymentsConfirmed,
      vouchersActive,
      vouchersUsed,
      ticketsOpen,
      ticketsResolved
    ] = await Promise.all([
      db.product.count(),
      db.movement.count(),
      db.alert.count(),
      db.payment.count({ where: { status: { in: ['PENDING', 'AWAITING_ADMIN'] } } }),
      db.payment.count({ where: { status: 'CONFIRMED' } }),
      db.voucher.count({ where: { status: 'ACTIVE' } }),
      db.voucher.count({ where: { status: 'USED' } }),
      db.supportTicket.count({ where: { status: { in: ['OPEN', 'IN_PROGRESS'] } } }),
      db.supportTicket.count({ where: { status: 'RESOLVED' } })
    ]);
    
    // Get revenue (sum of confirmed payments)
    const confirmedPayments = await db.payment.findMany({
      where: { status: 'CONFIRMED' },
      select: { amount: true }
    });
    
    const totalRevenue = confirmedPayments.reduce((sum, p) => sum + p.amount, 0);
    
    // Get recent payments (last 7 days)
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    
    const recentPayments = await db.payment.findMany({
      where: {
        createdAt: { gte: sevenDaysAgo }
      },
      orderBy: { createdAt: 'desc' },
      take: 10
    });
    
    // Get recent tickets
    const recentTickets = await db.supportTicket.findMany({
      orderBy: { createdAt: 'desc' },
      take: 5
    });
    
    // Get payment method distribution
    const paymentsByMethod = await db.payment.groupBy({
      by: ['methodType'],
      _count: { id: true },
      where: { status: 'CONFIRMED' }
    });
    
    // Get plan distribution (from vouchers)
    const vouchersByPlan = await db.voucher.groupBy({
      by: ['plan'],
      _count: { id: true }
    });
    
    // Get daily stats for last 7 days
    const dailyStats = await db.dailyStats.findMany({
      where: {
        date: { gte: sevenDaysAgo }
      },
      orderBy: { date: 'asc' }
    });
    
    return NextResponse.json({
      success: true,
      dashboard: {
        overview: {
          productsCount,
          movementsCount,
          alertsCount,
          paymentsPending,
          paymentsConfirmed,
          vouchersActive,
          vouchersUsed,
          ticketsOpen,
          ticketsResolved,
          totalRevenue
        },
        subscription: subscription ? {
          plan: subscription.plan,
          status: subscription.status,
          maxProducts: subscription.maxProducts
        } : null,
        recentPayments,
        recentTickets,
        paymentsByMethod: paymentsByMethod.map(m => ({
          method: m.methodType,
          count: m._count.id
        })),
        vouchersByPlan: vouchersByPlan.map(v => ({
          plan: v.plan,
          count: v._count.id
        })),
        dailyStats
      }
    });
  } catch (error) {
    console.error('Erreur dashboard:', error);
    return NextResponse.json({ success: false, error: 'Erreur serveur' }, { status: 500 });
  }
}

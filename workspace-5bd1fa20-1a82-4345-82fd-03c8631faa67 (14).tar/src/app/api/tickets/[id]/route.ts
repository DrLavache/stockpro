import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Récupérer un ticket spécifique
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const ticket = await db.supportTicket.findUnique({
      where: { id }
    });
    
    if (!ticket) {
      return NextResponse.json({ 
        success: false, 
        error: 'Ticket non trouvé' 
      }, { status: 404 });
    }
    
    return NextResponse.json({ success: true, ticket });
  } catch (error) {
    console.error('Erreur récupération ticket:', error);
    return NextResponse.json({ success: false, error: 'Erreur serveur' }, { status: 500 });
  }
}

// PUT - Mettre à jour un ticket (réponse admin)
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { status, priority, adminReply, repliedBy } = body;
    
    const ticket = await db.supportTicket.findUnique({
      where: { id }
    });
    
    if (!ticket) {
      return NextResponse.json({ 
        success: false, 
        error: 'Ticket non trouvé' 
      }, { status: 404 });
    }
    
    const updateData: {
      status?: string;
      priority?: string;
      adminReply?: string;
      repliedAt?: Date;
      repliedBy?: string;
      closedAt?: Date;
    } = {};
    
    if (status) {
      updateData.status = status;
      if (status === 'CLOSED' || status === 'RESOLVED') {
        updateData.closedAt = new Date();
      }
    }
    
    if (priority) updateData.priority = priority;
    
    if (adminReply) {
      updateData.adminReply = adminReply;
      updateData.repliedAt = new Date();
      updateData.repliedBy = repliedBy || 'admin';
    }
    
    const updated = await db.supportTicket.update({
      where: { id },
      data: updateData
    });
    
    // Log l'activité
    await db.activityLog.create({
      data: {
        action: adminReply ? 'TICKET_REPLIED' : 'TICKET_UPDATED',
        entityType: 'TICKET',
        entityId: id,
        details: JSON.stringify({ status, priority, hasReply: !!adminReply })
      }
    });
    
    return NextResponse.json({ 
      success: true, 
      ticket: updated,
      message: 'Ticket mis à jour' 
    });
  } catch (error) {
    console.error('Erreur mise à jour ticket:', error);
    return NextResponse.json({ success: false, error: 'Erreur serveur' }, { status: 500 });
  }
}

// DELETE - Supprimer un ticket
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    await db.supportTicket.delete({
      where: { id }
    });
    
    return NextResponse.json({ 
      success: true, 
      message: 'Ticket supprimé' 
    });
  } catch (error) {
    console.error('Erreur suppression ticket:', error);
    return NextResponse.json({ success: false, error: 'Erreur serveur' }, { status: 500 });
  }
}

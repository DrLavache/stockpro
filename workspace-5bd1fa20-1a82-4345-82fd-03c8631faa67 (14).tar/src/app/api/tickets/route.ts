import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Récupérer tous les tickets
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const type = searchParams.get('type');
    
    const where: {
      status?: string;
      type?: string;
    } = {};
    
    if (status) where.status = status;
    if (type) where.type = type;
    
    const tickets = await db.supportTicket.findMany({
      where,
      orderBy: [
        { priority: 'desc' },
        { createdAt: 'desc' }
      ],
      take: 100
    });
    
    return NextResponse.json({ success: true, tickets });
  } catch (error) {
    console.error('Erreur récupération tickets:', error);
    return NextResponse.json({ success: false, error: 'Erreur serveur' }, { status: 500 });
  }
}

// POST - Créer un nouveau ticket
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, subject, message, userName, userEmail, userPhone, paymentId, voucherCode } = body;
    
    if (!type || !subject || !message || !userEmail) {
      return NextResponse.json({ 
        success: false, 
        error: 'Type, sujet, message et email requis' 
      }, { status: 400 });
    }
    
    // Déterminer la priorité automatiquement
    let priority = 'NORMAL';
    if (type === 'PAYMENT_ISSUE' || type === 'COMPLAINT') {
      priority = 'HIGH';
    }
    
    const ticket = await db.supportTicket.create({
      data: {
        type,
        subject,
        message,
        userName,
        userEmail,
        userPhone,
        paymentId,
        voucherCode,
        priority
      }
    });
    
    // Log l'activité
    await db.activityLog.create({
      data: {
        action: 'TICKET_CREATED',
        entityType: 'TICKET',
        entityId: ticket.id,
        details: JSON.stringify({ type, subject, email: userEmail })
      }
    });
    
    return NextResponse.json({ 
      success: true, 
      ticket,
      message: 'Votre message a été envoyé. Nous vous répondrons dans les plus brefs délais.' 
    });
  } catch (error) {
    console.error('Erreur création ticket:', error);
    return NextResponse.json({ success: false, error: 'Erreur serveur' }, { status: 500 });
  }
}

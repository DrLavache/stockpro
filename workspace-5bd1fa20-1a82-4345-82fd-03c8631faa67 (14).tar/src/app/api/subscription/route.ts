import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get current subscription status
export async function GET() {
  try {
    const subscription = await db.subscription.findFirst({
      orderBy: { createdAt: 'desc' }
    });
    
    const settings = await db.settings.findFirst();
    
    return NextResponse.json({ 
      success: true,
      subscription: subscription ? {
        plan: subscription.plan,
        status: subscription.status,
        startDate: subscription.startDate,
        endDate: subscription.endDate,
        maxProducts: subscription.maxProducts,
        maxMovements: subscription.maxMovements,
        maxAlerts: subscription.maxAlerts,
        features: {
          emailAlerts: subscription.emailAlerts,
          aiEmails: subscription.aiEmails,
          exportData: subscription.exportData,
          apiAccess: subscription.apiAccess,
          prioritySupport: subscription.prioritySupport,
          customBranding: subscription.customBranding
        }
      } : null,
      settings: settings ? {
        companyName: settings.companyName,
        companyAddress: settings.companyAddress,
        companyPhone: settings.companyPhone,
        companyEmail: settings.companyEmail
      } : null
    });
    
  } catch (error) {
    console.error('Erreur récupération subscription:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur serveur' 
    }, { status: 500 });
  }
}

// POST - Activate voucher
export async function POST(request: Request) {
  try {
    const { voucherCode } = await request.json();
    
    if (!voucherCode) {
      return NextResponse.json({ 
        success: false, 
        error: 'Code voucher requis' 
      }, { status: 400 });
    }
    
    const voucher = await db.voucher.findUnique({
      where: { code: voucherCode.toUpperCase() }
    });
    
    if (!voucher) {
      return NextResponse.json({ 
        success: false, 
        error: 'Code invalide' 
      }, { status: 404 });
    }
    
    if (voucher.status === 'USED') {
      return NextResponse.json({ 
        success: false, 
        error: 'Ce code a déjà été utilisé' 
      }, { status: 400 });
    }
    
    if (voucher.status === 'EXPIRED' || (voucher.expiresAt && new Date() > voucher.expiresAt)) {
      return NextResponse.json({ 
        success: false, 
        error: 'Ce code a expiré' 
      }, { status: 400 });
    }
    
    // Plan limits
    const planLimits: Record<string, { maxProducts: number; maxMovements: number; maxAlerts: number }> = {
      STARTER: { maxProducts: 10, maxMovements: 100, maxAlerts: 10 },
      PRO: { maxProducts: 50, maxMovements: 500, maxAlerts: 50 },
      ENTERPRISE: { maxProducts: 999999, maxMovements: 999999, maxAlerts: 999999 }
    };
    
    const limits = planLimits[voucher.plan] || planLimits.STARTER;
    
    // Update or create subscription
    const existingSub = await db.subscription.findFirst();
    
    const result = await db.$transaction(async (tx) => {
      // Mark voucher as used
      await tx.voucher.update({
        where: { id: voucher.id },
        data: {
          status: 'USED',
          usedAt: new Date()
        }
      });
      
      // Create or update subscription
      let subscription;
      if (existingSub) {
        // Extend subscription
        const newEndDate = new Date();
        newEndDate.setDate(newEndDate.getDate() + voucher.duration);
        
        subscription = await tx.subscription.update({
          where: { id: existingSub.id },
          data: {
            plan: voucher.plan,
            status: 'ACTIVE',
            startDate: new Date(),
            endDate: newEndDate,
            ...limits,
            prioritySupport: voucher.plan === 'PRO' || voucher.plan === 'ENTERPRISE',
            customBranding: voucher.plan === 'ENTERPRISE'
          }
        });
      } else {
        const endDate = new Date();
        endDate.setDate(endDate.getDate() + voucher.duration);
        
        subscription = await tx.subscription.create({
          data: {
            plan: voucher.plan,
            status: 'ACTIVE',
            startDate: new Date(),
            endDate,
            ...limits,
            prioritySupport: voucher.plan === 'PRO' || voucher.plan === 'ENTERPRISE',
            customBranding: voucher.plan === 'ENTERPRISE'
          }
        });
      }
      
      // Log activity
      await tx.activityLog.create({
        data: {
          action: 'VOUCHER_USED',
          entityType: 'VOUCHER',
          entityId: voucher.id,
          details: JSON.stringify({
            code: voucherCode,
            plan: voucher.plan
          })
        }
      });
      
      return subscription;
    });
    
    return NextResponse.json({ 
      success: true,
      subscription: result,
      message: `Abonnement ${voucher.plan} activé pour ${voucher.duration} jours !`
    });
    
  } catch (error) {
    console.error('Erreur activation voucher:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur lors de l\'activation' 
    }, { status: 500 });
  }
}

import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get visible payment methods for clients
export async function GET() {
  try {
    const methods = await db.paymentMethod.findMany({
      where: {
        isActive: true,
        isVisible: true
      },
      orderBy: [
        { type: 'asc' },
        { createdAt: 'asc' }
      ]
    });
    
    return NextResponse.json({ 
      success: true, 
      methods 
    });
  } catch (error) {
    console.error('Erreur récupération méthodes:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur serveur' 
    }, { status: 500 });
  }
}

// POST - Submit a payment
export async function POST(request: Request) {
  try {
    const data = await request.json();
    const { 
      amount, 
      currency, 
      paymentMethod, 
      methodType, 
      reference, 
      txHash, 
      notes, 
      requestedPlan,
      duration, // MONTHLY, QUARTERLY, YEARLY
      userEmail, 
      userPhone 
    } = data;
    
    if (!amount || !paymentMethod || !methodType) {
      return NextResponse.json({ 
        success: false, 
        error: 'Données manquantes' 
      }, { status: 400 });
    }
    
    // Generate reference if not provided
    const paymentReference = reference || `PAY-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    
    const payment = await db.payment.create({
      data: {
        amount: parseFloat(amount),
        currency: currency || 'XOF',
        paymentMethod,
        methodType,
        reference: paymentReference,
        txHash: txHash || null,
        status: 'AWAITING_ADMIN',
        notes: notes || null,
        requestedPlan: requestedPlan || null,
        requestedDuration: duration || 'MONTHLY',
        userEmail: userEmail || null,
        userPhone: userPhone || null,
        expiresAt: new Date(Date.now() + 48 * 60 * 60 * 1000) // 48h expiry
      }
    });
    
    // Log activity
    await db.activityLog.create({
      data: {
        action: 'PAYMENT_CREATED',
        entityType: 'PAYMENT',
        entityId: payment.id,
        details: JSON.stringify({
          amount,
          paymentMethod,
          requestedPlan,
          duration,
          userEmail
        })
      }
    });
    
    return NextResponse.json({ 
      success: true,
      payment,
      message: 'Paiement soumis avec succès. Vous recevrez votre licence après confirmation (sous 24-48h).'
    });
    
  } catch (error) {
    console.error('Erreur soumission paiement:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur lors de la soumission' 
    }, { status: 500 });
  }
}

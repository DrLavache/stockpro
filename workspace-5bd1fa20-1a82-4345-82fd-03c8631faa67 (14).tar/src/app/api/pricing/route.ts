import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get public pricing (for clients)
export async function GET() {
  try {
    const pricings = await db.pricingConfig.findMany({
      where: { isActive: true },
      orderBy: { displayOrder: 'asc' }
    });
    
    return NextResponse.json({ 
      success: true, 
      pricings: pricings.map(p => ({
        plan: p.plan,
        monthlyPrice: p.monthlyPrice,
        monthlyEnabled: p.monthlyEnabled,
        quarterlyPrice: p.quarterlyPrice,
        quarterlyEnabled: p.quarterlyEnabled,
        quarterlyDiscount: p.quarterlyDiscount,
        yearlyPrice: p.yearlyPrice,
        yearlyEnabled: p.yearlyEnabled,
        yearlyDiscount: p.yearlyDiscount,
        features: p.features ? JSON.parse(p.features) : [],
        isPopular: p.isPopular
      }))
    });
  } catch (error) {
    console.error('Erreur récupération pricing:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur serveur' 
    }, { status: 500 });
  }
}

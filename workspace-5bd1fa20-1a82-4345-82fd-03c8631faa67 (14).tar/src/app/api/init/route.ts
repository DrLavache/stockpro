import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Initialize default data - called automatically on first deployment
export async function GET() {
  try {
    // Create default admin settings
    try {
      await db.adminSettings.upsert({
        where: { id: 'default' },
        update: {},
        create: {
          id: 'default',
          adminPassword: process.env.ADMIN_PASSWORD || 'admin123',
          requireAdminApproval: true,
          autoGenerateVoucher: false
        }
      });
    } catch {
      console.log('AdminSettings exists');
    }
    
    // Create default admin email
    try {
      const existingEmail = await db.adminEmail.count();
      if (existingEmail === 0) {
        await db.adminEmail.create({
          data: {
            email: process.env.ADMIN_EMAIL || 'icholababoukari@outlook.com',
            isActive: true
          }
        });
      }
    } catch {
      console.log('AdminEmail exists');
    }
    
    // Create default payment methods if not exist
    try {
      const existingMethods = await db.paymentMethod.count();
      if (existingMethods === 0) {
        await db.paymentMethod.createMany({
          data: [
            {
              type: 'MTN',
              name: 'MTN Mobile Money',
              accountName: 'MTN Payment',
              accountNumber: '0152877272',
              isVisible: true,
              isActive: true,
              instructions: 'Envoyez le montant au numéro MTN indiqué. Inscrivez la référence de la transaction dans le formulaire.'
            },
            {
              type: 'CELTIIS',
              name: 'Celtiis Money',
              accountName: 'Celtiis Payment',
              accountNumber: '0140738501',
              isVisible: true,
              isActive: true,
              instructions: 'Envoyez le montant au numéro Celtiis indiqué. Inscrivez la référence de la transaction dans le formulaire.'
            },
            {
              type: 'CRYPTO',
              name: 'USDC (Base Network)',
              accountName: 'USDC Base',
              accountNumber: '0x742d35Cc6634C0532925a3b844Bc9e7595f8C2dF',
              network: 'Base',
              isVisible: true,
              isActive: true,
              instructions: 'Envoyez exactement le montant en USDC sur le réseau Base. Copiez le hash de la transaction.'
            },
            {
              type: 'CRYPTO',
              name: 'Pi Network',
              accountName: 'Pi Wallet',
              accountNumber: 'pi_network_official_wallet',
              network: 'Pi Network',
              isVisible: true,
              isActive: true,
              instructions: 'Envoyez le montant en Pi via le wallet Pi Network. Notez votre username Pi comme référence.'
            }
          ]
        });
      }
    } catch {
      console.log('PaymentMethod exists');
    }
    
    // Create default pricing if not exist
    try {
      const existingPricing = await db.pricingConfig.count();
      if (existingPricing === 0) {
        await db.pricingConfig.createMany({
          data: [
            {
              plan: 'STARTER',
              monthlyPrice: 5000,
              monthlyEnabled: true,
              quarterlyPrice: 13500,
              quarterlyEnabled: true,
              quarterlyDiscount: 10,
              yearlyPrice: 48000,
              yearlyEnabled: true,
              yearlyDiscount: 20,
              features: JSON.stringify([
                "Jusqu'à 10 produits",
                '100 mouvements/mois',
                '10 alertes stock',
                'Support email',
                'Export CSV'
              ]),
              isActive: true,
              isPopular: false,
              displayOrder: 1,
              maxProducts: 10,
              maxMovements: 100,
              maxAlerts: 10
            },
            {
              plan: 'PRO',
              monthlyPrice: 15000,
              monthlyEnabled: true,
              quarterlyPrice: 40500,
              quarterlyEnabled: true,
              quarterlyDiscount: 10,
              yearlyPrice: 144000,
              yearlyEnabled: true,
              yearlyDiscount: 20,
              features: JSON.stringify([
                "Jusqu'à 50 produits",
                '500 mouvements/mois',
                '50 alertes stock',
                'Alertes email illimitées',
                'Export PDF & Excel',
                'Support prioritaire',
                'API Access'
              ]),
              isActive: true,
              isPopular: true,
              displayOrder: 2,
              maxProducts: 50,
              maxMovements: 500,
              maxAlerts: 50
            },
            {
              plan: 'ENTERPRISE',
              monthlyPrice: 50000,
              monthlyEnabled: true,
              quarterlyPrice: 135000,
              quarterlyEnabled: true,
              quarterlyDiscount: 10,
              yearlyPrice: 480000,
              yearlyEnabled: true,
              yearlyDiscount: 20,
              features: JSON.stringify([
                'Produits illimités',
                'Mouvements illimités',
                'Alertes illimitées',
                'Alertes email & IA',
                'Export avancé',
                'Support 24/7',
                'API illimitée',
                'Marque personnalisée'
              ]),
              isActive: true,
              isPopular: false,
              displayOrder: 3,
              maxProducts: 999999,
              maxMovements: 999999,
              maxAlerts: 999999
            }
          ]
        });
      }
    } catch {
      console.log('PricingConfig exists');
    }
    
    // Create free subscription if not exist
    try {
      const existingSub = await db.subscription.count();
      if (existingSub === 0) {
        await db.subscription.create({
          data: {
            plan: 'FREE',
            status: 'ACTIVE',
            maxProducts: 3,
            maxMovements: 50,
            maxAlerts: 5
          }
        });
      }
    } catch {
      console.log('Subscription exists');
    }
    
    return NextResponse.json({ 
      success: true,
      message: 'Base de données initialisée avec succès',
      initialized: true
    });
    
  } catch (error) {
    console.error('Erreur initialisation:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Erreur lors de l\'initialisation' 
    }, { status: 500 });
  }
}
